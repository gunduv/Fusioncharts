package com.cg.th.ext;

public abstract class Task {
  private Input input;
  private ConfigParms configParms;
  private String count;
  private String name;
  private Output output;
  
  public Task(ConfigParms configParms, String name){
	  this.name = name;
	  this.configParms = configParms;
  }

  public abstract boolean hasInput();
  public abstract boolean hasOutput();
  
public Input getInput() {
	if(input==null){
		input = new Input();
		input.configure(configParms);
	}
	return input;
}



public Output getOutput() {
	if(output==null){
		this.output = new Output();
		output.configure(configParms);
	}
	return output;
}


public abstract void setValues(ValueBean valueBean);

public String getCount() {
	return count;
}

public void setCount(String count) {
	this.count = count;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
  
}
