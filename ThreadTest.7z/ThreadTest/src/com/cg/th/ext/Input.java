package com.cg.th.ext;

import java.util.Random;

public class Input {
	public ConfigParms configParms;
	
	public void configure(ConfigParms configParms){
		this.configParms = configParms;
	}
	
	public String read(){
        Random random = new Random();
        try {
			Thread.sleep(random.nextInt(1000));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//        System.out.println("read: " + this.configParms.query);
		return this.configParms.query;
	}

}
