package com.cg.th.ext;

public class ConfigParms {
    public String query;

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}
    
}
