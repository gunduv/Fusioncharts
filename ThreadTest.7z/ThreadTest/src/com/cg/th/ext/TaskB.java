package com.cg.th.ext;

public class TaskB extends Task {

	public TaskB(ConfigParms configParms) {
		super(configParms, "B");
	}

	@Override
	public void setValues(ValueBean valueBean) {
		valueBean.setY(getCount());
	}

	@Override
	public boolean hasInput() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean hasOutput() {
		// TODO Auto-generated method stub
		return false;
	}

}
