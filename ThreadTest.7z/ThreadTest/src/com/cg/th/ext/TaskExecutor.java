package com.cg.th.ext;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

public class TaskExecutor {
    public static void main(String[] args) 
    {
    	TaskExecutor taskExecutor = new TaskExecutor();
    	taskExecutor.execute();
    }
    
    public void execute(){
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(200);
        List<Future<Integer>> resultList = new ArrayList<Future<Integer>>();
        	  CompletionService<Integer> taskCompletionService =
                new ExecutorCompletionService<Integer>(executor);        		  
        
    	long start = new Date().getTime();
    	ConfigParms configParms = new ConfigParms();
    	Random random = new Random();
        for (int i=0; i<10; i++)
        {
            try {
    			Thread.sleep(random.nextInt(1000));
    		} catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

            final LinkedList<Task> ll = new LinkedList<Task>();
//            	configParms = new ConfigParms();
            	configParms.setQuery(String.valueOf(i+1));
            	Task task = new TaskA(configParms);
            	ll.add(task);
            	task = new TaskB(configParms);
            	ll.add(task);
            	task = new TaskC(configParms);
            	ll.add(task);
            	task = new TaskOut(configParms);
            	ll.add(task);
            
            
            Future<Integer> result = 
            		executor.submit(
          				 new Callable<Integer>() {
							
							@Override
							public Integer call() throws Exception {
								Integer num = submit(ll);
								return num;
							}
						});
            resultList.add(result);
            
        }
        //shut down the executor service now
        executor.shutdown();
        
         for(int j=0;j<resultList.size();j++){
          try
              {
              	Future<Integer> future = taskCompletionService.take();
              	int total =future.get(); 
//                  System.out.println("Future result is - " + " - " + total + "; And Task done is " + future.isDone());
//                  System.out.println("Complted jobs:" + j);
              } 
              catch (Exception e) 
              {
                  e.printStackTrace();
              }
}
          long end = new Date().getTime();
          System.out.println("Time taken to end program: " + (end-start));
    }


    private Integer submit(final LinkedList<Task> ll){
    	Integer num = 0;
    	ValueBean valueBean = new ValueBean();
    	for(Task task : ll){
    		if(task.hasInput()){
    		num = Integer.parseInt(task.getInput().read());
    		task.setCount(num+"");
    		task.setValues(valueBean);
//    		System.out.println(num);
    		}
    		if(task.hasOutput()){
    			task.getOutput().write(valueBean);
    		}
    	}
    	return num;
    }
}
