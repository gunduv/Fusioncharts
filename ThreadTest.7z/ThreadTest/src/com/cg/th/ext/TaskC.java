package com.cg.th.ext;

public class TaskC extends Task {

	public TaskC(ConfigParms configParms) {
		super(configParms, "C");
	}

	@Override
	public void setValues(ValueBean valueBean) {
		valueBean.setZ(getCount());
	}

	@Override
	public boolean hasInput() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean hasOutput() {
		// TODO Auto-generated method stub
		return false;
	}

}
