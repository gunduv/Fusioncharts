package com.cg.th.ext;

public class TaskOut extends Task {

	public TaskOut(ConfigParms configParms) {
		super(configParms, "Out");
	}

	@Override
	public void setValues(ValueBean valueBean) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean hasInput() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean hasOutput() {
		// TODO Auto-generated method stub
		return true;
	}

}
