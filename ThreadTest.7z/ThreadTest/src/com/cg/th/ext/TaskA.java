package com.cg.th.ext;

public class TaskA extends Task {

	public TaskA(ConfigParms configParms) {
		super(configParms, "A");
	}

	@Override
	public void setValues(ValueBean valueBean) {
		valueBean.setX(getCount());
	}

	@Override
	public boolean hasInput() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean hasOutput() {
		// TODO Auto-generated method stub
		return false;
	}

	
	
}
