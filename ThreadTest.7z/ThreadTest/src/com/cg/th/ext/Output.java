package com.cg.th.ext;

public class Output {
	public ConfigParms configParms;
	
	public void configure(ConfigParms configParms){
		this.configParms = configParms;
	}
	
	public void write(ValueBean valueBean){
		System.out.println("name: " + valueBean.getX() + ", name: " + valueBean.getY() + ", " + "name: " + valueBean.getZ() + ", ");
	}
}
