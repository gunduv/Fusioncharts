package com.cg.th;

import java.util.Calendar;

public class BusinessDate {
	
	static final String daysOfTheWeek = "mo,te,we,th,fr";
	static final String[] days = new String[] {"20171117", "20171120", "20171121"};
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(System.currentTimeMillis());
		
		Calendar cal2 = Calendar.getInstance();
		cal2.setTimeInMillis(System.currentTimeMillis());
		
		
	}
	
	
	
	
	

}
