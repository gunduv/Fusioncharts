package com.igate.sa.webanalytics;

import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.igate.sa.webanalytics.vo.WebanalyticsVO;

public class WebAnalyticsDAO {

	public WebanalyticsVO getAnalyticsData(String companyName) {
		WebanalyticsVO webanalyticsVO = new WebanalyticsVO();
		
		SortedMap<String, String> rankData = new TreeMap<String, String>();
		rankData.put("Oct-14", "22182");
		rankData.put("Sep-14", "19292");
		rankData.put("Aug-14", "18917");
		rankData.put("July-14", "20553");
		rankData.put("June-14", "22122");
		rankData.put("May-14", "25039");
		webanalyticsVO.setRankData(rankData);
		
		SortedMap<String, String> uniqueVisitors = new TreeMap<String, String>();
		uniqueVisitors.put("Oct-14", "108056");
		uniqueVisitors.put("Sep-14", "116630");
		uniqueVisitors.put("Aug-14", "120011");
		uniqueVisitors.put("July-14", "107009");
		uniqueVisitors.put("June-14", "92698");
		uniqueVisitors.put("May-14", "83021");
		webanalyticsVO.setUniqueVisitors(uniqueVisitors);
		
		SortedMap<String, String> pageVisits = new TreeMap<String, String>();
		pageVisits.put("Oct-14", "404156");
		pageVisits.put("Sep-14", "231798");
		pageVisits.put("Aug-14", "264906");
		pageVisits.put("July-14", "264023");
		pageVisits.put("June-14", "197275");
		pageVisits.put("May-14", "162961");
		webanalyticsVO.setPageVisits(pageVisits);
		
		SortedMap<String, String> visitsPerPerson = new TreeMap<String, String>();
		visitsPerPerson.put("Oct-14", "1.31");
		visitsPerPerson.put("Sep-14", "1.07");
		visitsPerPerson.put("Aug-14", "1.13");
		visitsPerPerson.put("July-14", "1.17");
		visitsPerPerson.put("June-14", "1.12");
		visitsPerPerson.put("May-14", "1.09");
		webanalyticsVO.setVisitsPerPerson(visitsPerPerson);
		
		
		SortedMap<String, String> pagesPerVisit = new TreeMap<String, String>();
		pagesPerVisit.put("Oct-14", "2.86");
		pagesPerVisit.put("Sep-14", "1.85");
		pagesPerVisit.put("Aug-14", "1.95");
		pagesPerVisit.put("July-14", "2.11");
		pagesPerVisit.put("June-14", "1.89");
		pagesPerVisit.put("May-14", "1.80");
		webanalyticsVO.setPagesPerVisit(pagesPerVisit);
		
		SortedMap<String, String> averageStay = new TreeMap<String, String>();
		averageStay.put("Oct-14", "235.25");
		averageStay.put("Sep-14", "130.75");
		averageStay.put("Aug-14", "179.56");
		averageStay.put("July-14", "224.43");
		averageStay.put("June-14", "208.81");
		averageStay.put("May-14", "163.06");
		webanalyticsVO.setAverageStay(averageStay);
		
		
		SortedMap<String, String> income = new TreeMap<String, String>();
		SortedMap<String, String> age = new TreeMap<String, String>();
		SortedMap<String, String> attention = new TreeMap<String, String>();

		
		return webanalyticsVO;
		
	}
	
}
