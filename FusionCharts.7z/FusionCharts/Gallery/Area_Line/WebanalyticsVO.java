package com.igate.sa.webanalytics.vo;

import java.util.Map;

public class WebanalyticsVO {

	private Map<String, String> rankData;
	private Map<String, String> uniqueVisitors;
	private Map<String, String> pageVisits;
	private Map<String, String> visitsPerPerson;
	private Map<String, String> pagesPerVisit;
	private Map<String, String> averageStay;
	private Map<String, String> income;
	private Map<String, String> age;
	private Map<String, String> attention;
	
	
	public Map<String, String> getVisitsPerPerson() {
		return visitsPerPerson;
	}
	public void setVisitsPerPerson(Map<String, String> visitsPerPerson) {
		this.visitsPerPerson = visitsPerPerson;
	}
	public Map<String, String> getPagesPerVisit() {
		return pagesPerVisit;
	}
	public void setPagesPerVisit(Map<String, String> pagesPerVisit) {
		this.pagesPerVisit = pagesPerVisit;
	}
	public Map<String, String> getAverageStay() {
		return averageStay;
	}
	public void setAverageStay(Map<String, String> averageStay) {
		this.averageStay = averageStay;
	}
	public Map<String, String> getIncome() {
		return income;
	}
	public void setIncome(Map<String, String> income) {
		this.income = income;
	}
	public Map<String, String> getAge() {
		return age;
	}
	public void setAge(Map<String, String> age) {
		this.age = age;
	}
	public Map<String, String> getAttention() {
		return attention;
	}
	public void setAttention(Map<String, String> attention) {
		this.attention = attention;
	}
	public Map<String, String> getPageVisits() {
		return pageVisits;
	}
	public void setPageVisits(Map<String, String> pageVisits) {
		this.pageVisits = pageVisits;
	}
	public Map<String, String> getRankData() {
		return rankData;
	}
	public void setRankData(Map<String, String> rankData) {
		this.rankData = rankData;
	}
	public Map<String, String> getUniqueVisitors() {
		return uniqueVisitors;
	}
	public void setUniqueVisitors(Map<String, String> uniqueVisitors) {
		this.uniqueVisitors = uniqueVisitors;
	}
	
	
}
