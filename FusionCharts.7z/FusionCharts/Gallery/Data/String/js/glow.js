var dataString ='<chart showPercentagevalues="1" caption="Company Revenue" chartrightmargin="45" bgcolor="FFFFFF" chartleftmargin="50" charttopmargin="35" chartbottommargin="20" showplotborder="0" showshadow="1" showborder="1" bordercolor="0080FF" borderalpha="50" bgalpha="50" >\n\
        <set value="26" color="C295F2"  label="Services"/>\n\
        <set value="32" color="00ACE8"  label="Hardware"/>\n\
        <set value="42" label="Software"/>\n\
        <styles>\n\
        <definition>\n\
          <style name="Font_0" type="font" font="Calibri" size="14" bold="1" bgcolor="FFFFFF" bordercolor="FFFFFF" isHTML="0"/>\n\
          <style name="Font_1" type="font" size="15" color="000080" bgcolor="FFFFFF" bordercolor="FFFFFF" isHTML="0"/>\n\
          <style name="Glow_0" type="Glow" color="0080FF" alpha="43" quality="3"/>\n\
        </definition>\n\
        <application>\n\
          <apply toObject="DATALABELS" styles="Font_0"/>\n\
          <apply toObject="CAPTION" styles="Font_1"/>\n\
          <apply toObject="DATAPLOT" styles="Glow_0"/>\n\
        </application>\n\
        </styles>\n\
      </chart>';
