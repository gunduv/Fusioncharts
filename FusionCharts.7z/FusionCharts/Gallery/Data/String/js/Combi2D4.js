var dataString ='<chart palette="2" caption="Sales" subCaption="March 2006" showValues="0" divLineDecimalPrecision="1" limitsDecimalPrecision="1" PYAxisName="Amount" SYAxisName="Quantity" numberPrefix="$" formatNumberScale="0" >\n\
<categories>\n\
<category label="A" />\n\
<category label="B" />\n\
<category label="C" />\n\
<category label="D" />\n\
<category label="E" />\n\
<category label="F" />\n\
<category label="G" />\n\
<category label="H" />\n\
<category label="I" />\n\
<category label="J" />\n\
</categories>\n\
\n\
<dataset seriesName="Revenue" >\n\
<set value="5854" />\n\
<set value="4171" />\n\
<set value="1375" />\n\
<set value="1875" />\n\
<set value="2246" />\n\
<set value="2696" />\n\
<set value="1287" />\n\
<set value="2140" />\n\
<set value="1603" />\n\
<set value="1628" />\n\
</dataset>\n\
<dataset seriesName="Profit" renderAs="Area">\n\
<set value="3242" />\n\
<set value="3171" />\n\
<set value="700" />\n\
<set value="1287" />\n\
<set value="1856" />\n\
<set value="1126" />\n\
<set value="987" />\n\
<set value="1610" />\n\
<set value="903" />\n\
<set value="928" />\n\
</dataset>\n\
<dataset seriesName="Predicted Profit" renderAs="Line">\n\
<set value="4342" />\n\
<set value="2371" />\n\
<set value="740" />\n\
<set value="3487" />\n\
<set value="2156" />\n\
<set value="1326" />\n\
<set value="1087" />\n\
<set value="1710" />\n\
<set value="703" />\n\
<set value="928" />\n\
</dataset>\n\
\n\
</chart>';