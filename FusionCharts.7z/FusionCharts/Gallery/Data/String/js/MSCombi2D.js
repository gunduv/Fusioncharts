var dataString ='<chart showvalues="0" numberprefix="$" chartrightmargin="40" bgcolor="FFFFFF" bgratio="0" bgalpha="100" showborder="0" canvasbgcolor="" numdivlines="0" showyaxisvalues="0" canvasbordercolor="FFFFFF" showlegend="0" labeldisplay="none" bordercolor="FFFFFF" showplotborder="0" plotgradientcolor="1F1F1F" showtooltip="0" basefontsize="11" basefont="Arial Black" basefontcolor="3F3F3F" drawanchors="0" linethickness="4" plotfillangle="" plotfillalpha="9" chartleftmargin="20" chartbottommargin="20" labelpadding="5" valuepadding="3" yaxisvaluespadding="4" animation="1">\n\
 <categories>\n\
  <category label="1920"/>\n\
  <category label="1930"/>\n\
  <category label="1940"/>\n\
  <category label="1950"/>\n\
  <category label="1960"/>\n\
  <category label="1970"/>\n\
  <category label="1980"/>\n\
  <category label="1990"/>\n\
  <category label="2010"/>\n\
 </categories>\n\
 <dataset seriesName="2008" parentyaxis="P" renderas="Column" alpha="100">\n\
  <set value="34" color="B99983"/>\n\
  <set value="47" color="819FB6"/>\n\
  <set value="76" color="EBB71A"/>\n\
  <set value="71" color="8CB416"/>\n\
  <set value="108" color="FF944F"/>\n\
  <set value="138" color="36A5A5"/>\n\
  <set value="162" color="DA5353"/>\n\
  <set value="202" color="5379DA"/>\n\
  <set value="265" color="AD4CE8"/>\n\
 </dataset>\n\
 <dataset seriesName="2007" color="D10C0C" parentyaxis="P" renderas="Line" alpha="100">\n\
  <set/>\n\
  <set value="22"/>\n\
  <set value="46"/>\n\
  <set value="29"/>\n\
  <set value="71"/>\n\
  <set value="55"/>\n\
  <set value="89" color="D10C0C" anchorsides="3" anchorradius="2" anchorbgcolor="D10C0C"/>\n\
  <set value="95" color="D10C0C" anchorsides="3" anchorradius="2" anchorbgcolor="D10C0C"/>\n\
  <set value="192" color="D10C0C" anchorsides="3" anchorradius="2" anchorbgcolor="D10C0C"/>\n\
 </dataset>\n\
 <styles><definition><style type="Shadow" name="Shadow_0" Angle="75" Color="400000" Alpha="80" blurX="2" blurY="2"/><style type="Bevel" name="Bevel_0" angle="90" Distance="1" shadowColor="333333" shadowAlpha="55"/><style type="Shadow" name="Shadow_colm" Distance="9" Angle="90" Color="000000" Alpha="19" blurX="0" blurY="15"/></definition><application><apply toObject="DATAPLOTLINE" styles="Shadow_0"/><apply toObject="DATAPLOTCOLUMN" styles="Bevel_0,Shadow_colm"/></application></styles></chart>';
