var dataString ='<chart yAxisName="Sales Figure" caption="Top 5 Sales Person" numberPrefix="$" useRoundEdges="1" bgColor="FFFFFF,FFFFFF" showBorder="0">\n\
	<set label="Alex" value="25000"  /> \n\
	<set label="Mark" value="35000" /> \n\
	<set label="David" value="42300" /> \n\
	<set label="Graham" value="35300" /> \n\
	<set label="John" value="31300" />\n\
\n\
</chart>';