var dataString ='<chart caption="Airline Delay Causes" showPercentageInLabel="1" showValues="1" showLabels="1" showLegend="1">\n\
	<set value="14.94" label="Weather" color="429EAD"/> \n\
	<set value="19.17" label="Volume" color="4249AD"/> \n\
	<set value="7.14" label="Closed Runway" color="AD42A2"/> \n\
	<set value="7.75" label="Others" color="D4AC31"/>\n\
</chart>';