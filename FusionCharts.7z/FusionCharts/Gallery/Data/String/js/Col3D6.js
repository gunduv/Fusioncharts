var dataString ='<chart palette="4" showValues="0" showBorder="1" forceYAxisValueDecimals="1"  yAxisValueDecimals="2">\n\
  <set label="Jan" value="11874" /> \n\
  <set label="Feb" value="15557" /> \n\
  <set label="Mar" value="" /> \n\
  <set label="Apr" value="11071" /> \n\
  <set label="May" value="11152" /> \n\
  <set label="Jun" value="" /> \n\
  <set label="Jul" value="7520" /> \n\
  <set label="Aug" value="" /> \n\
  <set label="Sep" value="" /> \n\
  </chart>';