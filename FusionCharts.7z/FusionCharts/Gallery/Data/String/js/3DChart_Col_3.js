﻿var dataString ='<chart caption="Weather Report" subCaption="Temperature"  xaxisname="Places" yaxisname="Degree  Fahrenheit"  clustered="0" zeroPlaneMesh="0" zeroPlaneColor="68BDFF" zeroPlaneAlpha="50" palette="3" bgColor="66D6FF,FFFFFF,ffffff" bgRatio="20,60,20" bgAlpha="10,10,40" divLineEffect="none" numDivLines="3" legendBgAlpha="90" legendShadow="0" intensity=".02" startAngX="4.5" startAngY="-6.6" endAngX="4.5" endAngY="-6.6" exeTime="2" numberSuffix="°">\n\
      <categories>\n\
        <category label="Jan"/>\n\
        <category label="Feb"/>\n\
        <category label="Mar"/>\n\
        <category label="Apr"/>\n\
        <category label="May"/>\n\
        <category label="Jun"/>\n\
        <category label="Jul"/>\n\
        <category label="Aug"/>\n\
        <category label="Sep"/>\n\
        <category label="Oct"/>\n\
        <category label="Nov"/>\n\
        <category label="Dec"/>\n\
      </categories>\n\
      <dataset seriesName="New York" color="F97D10" >\n\
        <set value="-6"/>\n\
        <set value="-15"/>\n\
        <set value="3"/>\n\
        <set value="12"/>\n\
        <set value="32"/>\n\
        <set value="44"/>\n\
        <set value="52"/>\n\
        <set value="50"/>\n\
        <set value="39"/>\n\
        <set value="28"/>\n\
        <set value="5"/>\n\
        <set value="-13"/>\n\
      </dataset>\n\
      <dataset seriesName="Chicago" >\n\
        <set value="-27"/>\n\
        <set value="-19"/>\n\
        <set value="-8"/>\n\
        <set value="7"/>\n\
        <set value="24"/>\n\
        <set value="36"/>\n\
        <set value="40"/>\n\
        <set value="41"/>\n\
        <set value="28"/>\n\
        <set value="17"/>\n\
        <set value="1"/>\n\
        <set value="-25"/>\n\
      </dataset>\n\
      <dataset seriesName="Bismarck" color="3994F9" >\n\
        <set value="-44"/>\n\
        <set value="-43"/>\n\
        <set value="-31"/>\n\
        <set value="-12"/>\n\
        <set value="15"/>\n\
        <set value="30"/>\n\
        <set value="35"/>\n\
        <set value="33"/>\n\
        <set value="11"/>\n\
        <set value="-10"/>\n\
        <set value="-30"/>\n\
        <set value="-43"/>\n\
      </dataset>\n\
<styles>\n\
<definition>\n\
<style name="captionFont" type="font" size="15" />\n\
</definition>\n\
<application>\n\
<apply toObject="caption" styles="captionfont" />\n\
</application>\n\
</styles>\n\
</chart>';
