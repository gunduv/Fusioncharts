var dataString ='<chart showvalues="0" caption="Production Forecast" chartrightmargin="20" showalternatehgridcolor="0" numdivlines="0" showyaxisvalues="0"  bgcolor="FFFFFF" showshadow="1" showborder="1" canvasborderalpha="0" bordercolor="4F4F4F" borderalpha="50" drawanchors="0"  linecolor="FF0000" anchorborderthickness="1" linethickness="4" numVDivLines="3">\n\
	<set value="436678" color="FF0000"  label="2006"/>\n\
	<set value="168099" color="FF0000"  label="2007"/>\n\
	<set value="300000" color="FF0000"  label="2008"/>\n\
	<set value="150000" color="FF0000"  label="2009"/>\n\
	<set value="190000" color="8BBA00"  label="2010"/>\n\
	<styles><definition><style name="Blur_0" type="Blur" blurx="16" blury="8"/></definition><application><apply toObject="DATAPLOT" styles="Blur_0"/></application></styles></chart>';
