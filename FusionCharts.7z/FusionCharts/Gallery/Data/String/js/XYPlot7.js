var dataString ='<chart caption="Income Expenditure Analysis" subcaption="(sample survey done among buyers of LCD TV)" xAxisName="Salary" yAxisName="Amount spent on LCD TV" showRegressionLine="1" xAxisLabelMode="auto">\n\
\n\
  <dataset color="000000">\n\
    <set x="9200" y="1600" />\n\
    <set x="9900" y="1800" />\n\
    <set x="9500" y="1510" />\n\
    <set x="9700" y="1400" />\n\
    <set x="8100" y="1500" />\n\
    <set x="8600" y="1300" />\n\
    <set x="8300" y="1220" />\n\
    <set x="7800" y="1300" />\n\
    <set x="7800" y="1220" />\n\
    <set x="7000" y="1210" />\n\
    <set x="6000" y="1140" />\n\
    <set x="6000" y="1000" />\n\
    <set x="6200" y="950" />\n\
    <set x="5300" y="940" />\n\
    <set x="4700" y="1000" />\n\
    <set x="4800" y="947" />\n\
    <set x="4500" y="850" />\n\
    <set x="4000" y="870" />\n\
    <set x="3700" y="800" />\n\
    <set x="3100" y="800" />\n\
    <set x="4500" y="600" />\n\
    <set x="4000" y="660" />\n\
    <set x="3600" y="500" />\n\
    <set x="3400" y="450" />\n\
    <set x="3100" y="650" />\n\
    <set x="3100" y="600" />\n\
    <set x="3100" y="540" />\n\
    <set x="2800" y="460" />\n\
    <set x="2400" y="650" />\n\
    <set x="2300" y="540" />\n\
    <set x="3000" y="340" />\n\
    <set x="2000" y="280" />\n\
    <set x="2200" y="340" />\n\
    <set x="2000" y="180" />    \n\
  </dataset>\n\
\n\
</chart>'; 