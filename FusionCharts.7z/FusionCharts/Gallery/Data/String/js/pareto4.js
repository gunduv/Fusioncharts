var dataString ='<chart showvalues="0" caption="Hardware Defects" canvasbgangle="0" canvasborderthickness="2" chartleftmargin="20" chartrightmargin="5" basefontsize="10" outcnvbasefontsize="13" bgcolor="F4FDF9" linecolor="000000" showplotborder="0" plotgradientcolor="" useroundedges="0" linethickness="3" linedashed="1" plotbordercolor="EFEFEF" showcanvasbg="0" showcanvasbase="0" canvasbasedepth="5" canvasbgdepth="1" zeroplaneshowborder="1" canvasbgcolor="0F0F0F" canvasbgalpha="100" canvasbasecolor="0F0F0F" anchorbordercolor="B70000" anchorbgcolor="CA0000" linedashlen="3" anchorradius="3" anchorsides="10" outcnvbasefontcolor="2D4230" outcnvbasefont="Calibri" bgalpha="30" showborder="0" bordercolor="427D4D" >\n\
 <set value="87" color="50BD4A"  label="Hard Disk"/>\n\
 <set value="79" color="50BD4A"  label="PCB"/>\n\
 <set value="37" color="50BD4A"  label="Printer"/>\n\
 <set value="62" color="50BD4A"  label="KeyBoard"/>\n\
 <set value="43" color="50BD4A"  label="CDROM"/>\n\
</chart>';
