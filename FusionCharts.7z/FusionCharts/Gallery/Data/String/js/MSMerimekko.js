var dataString ='<chart showvalues="0" caption="Market Share Analysis" subcaption="2009" numberprefix="$" xaxisname="Market Segment" pyaxisname="Market Share" legendcaption="Manufacturer" >\n\
\n\
   <categories>\n\
     <category label="Desktop"/>\n\
     <category label="Laptop"/>\n\
     <category label="Notebook"/>\n\
   </categories>\n\
\n\
   <dataset seriesName="A">\n\
     <set value="335000"/>\n\
     <set value="225100"/>\n\
     <set value="164200"/>\n\
   </dataset>\n\
\n\
   <dataset seriesName="B">\n\
     <set value="215000"/>\n\
     <set value="198000"/>\n\
     <set value="120000"/>\n\
   </dataset>\n\
\n\
   <dataset seriesName="C">\n\
     <set value="298000"/>\n\
     <set value="109300"/>\n\
     <set value="153600"/>\n\
   </dataset>\n\
\n\
</chart>';