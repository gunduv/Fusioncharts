var dataString ='<chart showvalues="0" yaxisname="Rise in sea level (cm)" numdivlines="0" canvasborderalpha="0" canvasbgalpha="1" numvdivlines="5" plotgradientcolor="0000FF" anchorradius="20" anchorbordercolor="004080" anchorbgcolor="004080" anchorbgalpha="50" anchorborderthickness="0" plotfillangle="90" plotfillalpha="63" vdivlinealpha="22" vdivlinecolor="6281B5" bgcolor="ABCAD3,B3CCE1" showplotborder="0" numbersuffix="%25" bordercolor="9DBCCC" borderalpha="100" canvasbgratio="0" basefontcolor="37444A" basefontsize="8" outcnvbasefontcolor="37444A" outcnvbasefontsize="11" showyaxisvalues="0" >\n\
 <set value="0" label="1880" color="0080C0"/>\n\
 <set value="2" label="1900" color="0080FF"/>\n\
 <set value="4" label="1920" color="0080C0"/>\n\
 <set value="6" label="1940" color="0080C0"/>\n\
 <set value="10" label="1960" color="0080C0"/>\n\
 <set value="13" label="1980" color="0080C0"/>\n\
 <set value="20" label="2000" color="0080C0"/>\n\
 	<trendLines>\n\
		<line startValue="5" color="6281B5" thickness=".5" alpha="50" showOnTop="0" />\n\
		<line startValue="10" color="6281B5" thickness=".5" alpha="50" showOnTop="0" />\n\
		<line startValue="15" color="6281B5" thickness=".5" alpha="50" showOnTop="0" />\n\
		<line startValue="20" color="6281B5" thickness=".5" alpha="50" showOnTop="0" />\n\
		<line startValue="25" color="6281B5" thickness=".5" alpha="50" showOnTop="0" />\n\
	</trendLines>\n\
 </chart>';
