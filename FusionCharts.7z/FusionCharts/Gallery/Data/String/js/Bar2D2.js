var dataString ='<chart yAxisName="Number of Leads" xAxisName="Industry" canvasBgColor="FFFFDD" bgColor="B8D288,FFFFFF" bgAngle="90" numDivLines="0" plotBorderColor="83B242" canvasBorderColor="83B242" canvasBorderThickness="1">\n\
	<set label="Advertising/Marketing/PR" value="3" color="83B242,B8D288"/>\n\
	<set label="Aerospace/Defense Products" value="1" color="83B242,B8D288" />\n\
	<set label="Banking/Finance/Securities" value="1" color="83B242,B8D288"/>\n\
	<set label="Communications/Cable/Phone" value="2" color="83B242,B8D288"/>\n\
	<set label="Conglomerates" value="0" color="83B242,B8D288"/>\n\
	<set label="Construction" value="2" color="83B242,B8D288"/>\n\
	<set label="Consumer Products - Non-Durables" value="1" color="83B242,B8D288"/>\n\
	<set label="Distribution" value="1" color="83B242,B8D288"/> \n\
	<set label="Education" value="1" color="83B242,B8D288"/>  \n\
	<set label="Enery - Oil &amp; Gas" value="0" color="83B242,B8D288"/>\n\
	<set label="Entertainment" value="2" color="83B242,B8D288"/>\n\
	<set label="Government" value="0" color="83B242,B8D288"/>\n\
	<set label="Health Products &amp; Services" value="1" color="83B242,B8D288"/>  \n\
	<set label="Hospitality &amp; Hotels" value="1" color="83B242,B8D288"/>\n\
	<set label="Insurance" value="0" color="83B242,B8D288"/>\n\
	<set label="ISP/Hotspot Operator" value="0" color="83B242,B8D288"/>\n\
	<set label="Non-Business/Residential" value="1" color="83B242,B8D288"/>\n\
	<set label="OEM &amp; Manufacturing" value="0" color="83B242,B8D288"/>\n\
	<set label="Other" value="3" color="83B242,B8D288"/>\n\
	<set label="Pharmaceutical" value="1" color="83B242,B8D288"/>\n\
	<set label="Point of Sale (POS)/Retail" value="0" color="83B242,B8D288"/>\n\
	<set label="Printer Service/Toner/Laser" value="0" color="83B242,B8D288"/>\n\
	<set label="Printing &amp; Publishing" value="1" color="83B242,B8D288"/>\n\
	<set label="Professional Services" value="1" color="83B242,B8D288"/>\n\
	<set label="Real Estate" value="3" color="83B242,B8D288"/>\n\
	<set label="REITs" value="0" color="83B242,B8D288"/>\n\
	<set label="Staffing Firm/Full Time/Temporary" value="2" color="83B242,B8D288"/>\n\
	<set label="Transportation/Logistics" value="2" color="83B242,B8D288"/>\n\
	<set label="Travel &amp; Leisure" value="4" color="83B242,B8D288" dashed="1" alpha="80"/>\n\
	<set label="Utilities" value="2" color="83B242,B8D288"/>\n\
	<set label="VAR/ISV" value="1" color="83B242,B8D288"/>\n\
	<set label="Vertical Market Software" value="0" color="83B242,B8D288"/>\n\
	<set label="Warranty Administrators" value="1" color="83B242,B8D288"/>\n\
	<set label="White Box Builder" value="0" color="83B242,B8D288"/>\n\
 </chart>';