var dataString ='<chart caption="Pie Chart" numberPrefix="$">\n\
	<set value="25" label="Item A" color="AFD8F8" /> \n\
	<set value="17" label="Item B" color="F6BD0F" /> \n\
	<set value="23" label="Item C" color="8BBA00" isSliced="1" /> \n\
	<set value="65" label="Item D" color="A66EDD" /> \n\
	<set value="22" label="Item E" color="F984A1" /> \n\
</chart>';