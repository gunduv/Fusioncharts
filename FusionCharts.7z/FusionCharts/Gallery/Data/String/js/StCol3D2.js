var dataString ='<chart caption="Breakdown of Revenue" subCaption="(into Products and Services)" xAxisName="Year" yAxisMaxValue="100" numberSuffix="%" \n\
areaBorderColor="FFFFFF" showValues="0" numVDivLines="3" palette="2">\n\
	<categories>\n\
		<category label="2004" />\n\
		<category label="2003" />\n\
		<category label="2002" />\n\
		<category label="2001" />\n\
		<category label="2000" />\n\
	</categories>\n\
\n\
	<dataset seriesName="Products">\n\
		<set value="65" /> \n\
		<set value="70" /> \n\
		<set value="60" /> \n\
		<set value="62" /> \n\
		<set value="48" /> \n\
		<set value="54" /> \n\
		<set value="46" /> \n\
	</dataset>\n\
\n\
	<dataset seriesName="Services" >\n\
		<set value="35" /> \n\
		<set value="30" /> \n\
		<set value="40" /> \n\
		<set value="38"/> \n\
		<set value="52" /> \n\
		<set value="46"  /> \n\
		<set value="54"/> \n\
	</dataset>\n\
\n\
	\n\
</chart>';
