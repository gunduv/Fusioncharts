var dataString ='<chart showvalues="0" caption="Market Share Analysis" numberprefix="$" xaxisname="Market Segment" yaxisname="Market Share"  stack100percent="0"  legendcaption="Manufacturer" canvasbgangle="0" canvasborderthickness="2" chartleftmargin="5" chartrightmargin="15" charttopmargin="10" chartbottommargin="20" captionpadding="10" xaxisnamepadding="5" yaxisnamepadding="5" yaxisvaluespadding="2" labelpadding="3" basefontsize="10" outcnvbasefontsize="10" bgcolor="FFFFFF" bgalpha="100" showxaxispercentvalues="1" usepercentdistribution="1" plotgradientcolor="" >\n\
	<categories>\n\
		<category label="Smart Phone" widthpercent=""/>\n\
		<category label="Basic Phone" widthpercent="33"/>\n\
		<category label="Camera Phone" widthpercent="34"/>\n\
		<category label="Music Phone"/>\n\
		<category label="Gaming Phone"/>\n\
	</categories>\n\
	<dataset seriesName="Alpha" color="F3D784" >\n\
		<set value="38500"/>\n\
		<set value="10510"/>\n\
		<set value="22420"/>\n\
		<set value="19600"/>\n\
		<set value="8000"/>\n\
	</dataset>\n\
	<dataset seriesName="Beta"  color="C9B26B">\n\
		<set value="34500"/>\n\
		<set value="9800"/>\n\
		<set value="18000"/>\n\
		<set value="23680"/>\n\
		<set value="8600"/>\n\
	</dataset>\n\
	<dataset seriesName="Gamma" color="A3893B" >\n\
		<set value="32800"/>\n\
		<set value="9930"/>\n\
		<set value="17360"/>\n\
		<set value="21769"/>\n\
		<set value="8655"/>\n\
	</dataset>\n\
	</chart>';