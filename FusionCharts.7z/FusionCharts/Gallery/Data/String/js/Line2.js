var dataString ='<chart caption="Monthly Sales Summary" subcaption="For the year 2004" xAxisName="Month" yAxisName="Sales" numberPrefix="$" showLabels="1" showColumnShadow="1" animation="1" showAlternateHGridColor="1" AlternateHGridColor="ff5904" divLineColor="ff5904" divLineAlpha="20" alternateHGridAlpha="5" canvasBorderColor="666666" baseFontColor="666666" lineColor="FF5904" lineAlpha="85" showValues="1" rotateValues="1" valuePosition="auto">\n\
<set label="Jan" value="17400" />\n\
<set label="Feb" value="19800" />\n\
<set label="Mar" value="21800" />\n\
<set label="Apr" value="23800" />\n\
<set label="May" value="29600" />\n\
<set label="Jun" value="27600" />\n\
<set label="Jul" value="31800" />\n\
<set label="Aug" value="39700" />\n\
<set label="Sep" value="37800" />\n\
<set label="Oct" value="21900" />\n\
<set label="Nov" value="32900" />\n\
<set label="Dec" value="39800" />\n\
</chart>';