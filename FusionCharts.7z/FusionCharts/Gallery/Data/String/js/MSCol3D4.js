var dataString ='<chart palette="1" xaxisname="Continent" yaxisname="Export" numdivlines="9" caption="Global Cereal Export" subcaption="In Millions Tonnes per annum per Hectare" >\n\
	<categories font="Arial" >\n\
		<category label="N. America" toolText="North America"/>\n\
		<category label="Asia" />\n\
		<category label="Europe" />\n\
		<category label="Australia" />\n\
		<category label="Africa" />\n\
\n\
	</categories>\n\
	<dataset seriesname="Rice" color="8BBA00" >\n\
		<set value="30" />\n\
		<set value="26" />\n\
		<set value="29" />\n\
		<set value="31" />\n\
		<set value="34" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="Wheat" color="A66EDD" >\n\
		<set value="67" />\n\
		<set value="98" />\n\
		<set value="79" />\n\
		<set value="73" />\n\
		<set value="80" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="Grain" color="F6BD0F" >\n\
		<set value="27" />\n\
		<set value="25" />\n\
		<set value="28" />\n\
		<set value="26" />\n\
		<set value="10" />\n\
	</dataset>\n\
\n\
</chart>';