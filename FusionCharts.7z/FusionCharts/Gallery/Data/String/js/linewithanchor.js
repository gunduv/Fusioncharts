var dataString ='<chart caption="Monthly Report" subCaption="Unique Visitors" yAxisName="Visitor Count" xAxisName="Date" \n\
	\n\
	showValues="0" showShadow="0" formatNumberScale="0" showLimits="0" \n\
	canvasBorderAlpha="0" showBorder="0"\n\
	divLineAlpha="30"\n\
		\n\
	anchorRadius="4" anchorBgColor="0377D0" anchorBorderColor="FFFFFF" anchorBorderThickness="1" anchorAlpha="90" \n\
	showPlotBorder="1" plotBorderThickness="4" plotBorderColor="0377D0" plotFillColor="0377D0"  plotGradientColor="" plotFillAlpha="20" bgColor="FFFFFF" \n\
	showAlternateHGridColor="0" numVDivLines="2" \n\
	 toolTipBgColor ="DEF1FF" toolTipBorderColor ="2C516D">\n\
	<set label="1 March 2009" value="490" />\n\
	<set label="2 March 2009" value="510" />\n\
	<set label="3 March 2009" value="1546" />\n\
	<set label="4 March 2009" value="1250" />\n\
	<set label="5 March 2009" value="1000" />\n\
	<set label="6 March 2009" value="540" />\n\
	<set label="7 March 2009" value="560" />\n\
	<set label="8 March 2009" value="580" />\n\
	<set label="9 March 2009" value="600" />\n\
	<set label="10 March 2009" value="620" />\n\
	<set label="11 March 2009" value="640" />\n\
	<set label="12 March 2009" value="660" />\n\
	<set label="13 March 2009" value="680" />\n\
	<set label="14 March 2009" value="700" />\n\
	<set label="15 March 2009" value="730" />\n\
	<set label="16 March 2009" value="760" />\n\
	<set label="17 March 2009" value="790" />\n\
	<set label="18 March 2009" value="800" />\n\
	<set label="19 March 2009" value="795" />\n\
	<set label="20 March 2009" value="790" />\n\
	<set label="21 March 2009" value="770" />\n\
	<set label="22 March 2009" value="750" />\n\
	<set label="23 March 2009" value="1150" />\n\
	<set label="24 March 2009" value="1140" />\n\
	<set label="25 March 2009" value="730" />\n\
	<set label="26 March 2009" value="710" />\n\
	<set label="27 March 2009" value="700" />\n\
	<set label="28 March 2009" value="690" />\n\
	<set label="29 March 2009" value="670" />\n\
	<set label="30 March 2009" value="680" />\n\
	<set label="31 March 2009" value="690" />\n\
\n\
\n\
</chart>';