var dataString ='<chart caption="Production Forecast" yAxisName="Units" bgColor="F7F7F7, E9E9E9" numVDivLines="10" divLineAlpha="30"  labelPadding ="10" yAxisValuesPadding ="10" showValues="1" rotateValues="1" valuePosition="auto">\n\
	<categories>\n\
		<category label="2006" /> \n\
		<category label="2007" /> \n\
		<category label="2008" /> \n\
		<category label="2009" /> \n\
		<category label="2010" /> \n\
		<category label="2011" /> \n\
	</categories>\n\
\n\
	<dataset seriesName="Model A12" color="A66EDD" >\n\
		<set value="35" /> \n\
		<set value="42" /> \n\
		<set value="31" /> \n\
		<set value="28" /> \n\
		<set value="34" /> \n\
		<set value="30" /> \n\
	</dataset>\n\
\n\
	<dataset seriesName="Model A15" color="F6BD0F">\n\
		<set value="22" /> \n\
		<set value="25" /> \n\
		<set value="18" /> \n\
		<set value="22" /> \n\
		<set value="17" /> \n\
		<set value="16" /> \n\
	</dataset>\n\
\n\
</chart>';