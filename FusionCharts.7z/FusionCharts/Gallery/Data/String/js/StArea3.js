var dataString ='<chart caption="Product-wise Sales" xAxisName="Day" canvasBgColor="E7D9E6" canvasBorderColor="B38CB0" canvasBorderThickness="1" baseFontColor="B38CB0" \n\
numberPrefix="$" decimalPrecision="0" decimalSeparator=","  rotateLabels="1" slantLabels="1" toolTipBorderColor="FFFFFF" showValues="0" legendBorderColor="B38CB0"> \n\
\n\
	<categories>\n\
		<category label="1" />\n\
		<category label="2" />\n\
		<category label="3" />\n\
		<category label="4" />\n\
		<category label="5" />\n\
		<category label="6" />\n\
		<category label="7" />\n\
		<category label="8" />\n\
		<category label="9" />\n\
		<category label="10" />\n\
		<category label="11" />\n\
		<category label="12" />\n\
		<category label="13" />\n\
		<category label="14" />\n\
		<category label="15" />\n\
		<category label="16" />\n\
		<category label="17" />\n\
		<category label="18" />\n\
		<category label="19" />\n\
		<category label="20" />\n\
		<category label="21" />\n\
		<category label="22" />\n\
		<category label="23" />\n\
		<category label="24" />\n\
		<category label="25" />\n\
		<category label="26" />\n\
		<category label="27" />\n\
		<category label="28" />\n\
		<category label="29" />\n\
		<category label="30" />\n\
		<category label="31" />      \n\
	</categories>\n\
\n\
	<dataset seriesName="Product A" color="049250">\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set value="57000" />\n\
		<set value="58995" />\n\
		<set value="61119" />\n\
		<set value="63502" />\n\
		<set value="65662" />\n\
		<set value="68157" />\n\
		<set value="69997" />\n\
		<set value="72797" />\n\
		<set value="75272" />\n\
		<set value="77455" />\n\
		<set value="79546" />\n\
		<set value="80739" />\n\
		<set value="82273" />\n\
		<set value="84001" />\n\
		<set value="85849" />\n\
		<set value="85868" />\n\
		<set value="87843" />\n\
		<set value="90039" />\n\
		<set value="61452" />\n\
		<set value="64463" />\n\
		<set value="65945" />\n\
		<set value="68056" />\n\
		<set value="70914" />\n\
		<set value="73467" />\n\
		<set value="76332" />\n\
		<set value="78927" />\n\
		<set value="81927" />      \n\
	</dataset>\n\
\n\
	<dataset seriesName="Product B" color="cf0a37">\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set value="15500" />\n\
		<set value="16361" />\n\
		<set value="17212" />\n\
		<set value="18443" />\n\
		<set value="19270" />\n\
		<set value="20782" />\n\
		<set value="21128" />\n\
		<set value="22606" />\n\
		<set value="23915" />\n\
		<set value="24982" />\n\
		<set value="26436" />\n\
		<set value="26810" />\n\
		<set value="27421" />\n\
		<set value="28162" />\n\
		<set value="30000" />\n\
		<set value="28965" />\n\
		<set value="29767" />\n\
		<set value="29559" />\n\
		<set value="26150" />\n\
		<set value="28349" />\n\
		<set value="28676" />\n\
		<set value="29221" />\n\
		<set value="30681" />\n\
		<set value="31665" />\n\
		<set value="33109" />\n\
		<set value="34062" />\n\
		<set value="35849" />      \n\
	</dataset>\n\
\n\
	<dataset seriesName="Product C" color="FEF000">\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set value="38000" />\n\
		<set value="39330" />\n\
		<set value="40746" />\n\
		<set value="42335" />\n\
		<set value="43774" />\n\
		<set value="45438" />\n\
		<set value="46665" />\n\
		<set value="48531" />\n\
		<set value="50181" />\n\
		<set value="51637" />\n\
		<set value="53031" />\n\
		<set value="53826" />\n\
		<set value="54849" />\n\
		<set value="56001" />\n\
		<set value="57233" />\n\
		<set value="57245" />\n\
		<set value="58562" />\n\
		<set value="60026" />\n\
		<set value="40968" />\n\
		<set value="42975" />\n\
		<set value="43964" />\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set />\n\
		<set />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Product D" color="F2572E">\n\
\n\
		<set value="10494" />\n\
		<set value="29221" />\n\
		<set value="30681" />\n\
		<set value="31665" />\n\
		<set value="33109" />\n\
		<set value="34062" />\n\
				<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
		<set value="0"/>\n\
	</dataset>\n\
\n\
</chart>';
