var dataString ='<chart caption="Population Chart" showValues="0" sNumberSuffix="%" decimals="3" setAdaptiveYMin="1" setAdaptiveSYMin="1" lineThickness="5">\n\
\n\
	<categories>\n\
		<category label="2000" />\n\
		<category label="2001" />\n\
		<category label="2002" />\n\
		<category label="2003" />\n\
		<category label="2004" />\n\
		<category label="2005" />\n\
	</categories>\n\
\n\
	<dataset seriesname="Population">\n\
		<set value="275562673"/>\n\
		<set value="278558081"/>\n\
		<set value="280562489"/>\n\
		<set value="290342551"/>\n\
		<set value="290342551"/>\n\
		<set value="293027112"/>\n\
\n\
	</dataset>\n\
\n\
	<dataset parentYAxis="S" seriesname="Birth Rate">\n\
		<set value="1.42"/>\n\
		<set value="1.42"/>\n\
		<set value="1.41"/>\n\
		<set value="1.414"/>\n\
		<set value="1.413"/>\n\
		<set value="1.414"/>\n\
	</dataset>\n\
\n\
	<dataset parentYAxis="S" seriesname="Death Rate" renderAs="Area">\n\
		<set value="0.87"/>\n\
		<set value="0.87"/>\n\
		<set value="0.87"/>\n\
		<set value="0.844"/>\n\
		<set value="0.834"/>\n\
		<set value="0.825"/>\n\
	</dataset>\n\
</chart>';
