var dataString ='<chart caption="Web Statistics" subCaption="Add To Favorites (% of unique visitors)" yAxisMaxValue="100" bgColor="406181, 6DA5DB"  bgAlpha="100" baseFontColor="FFFFFF" canvasBgAlpha="0" canvasBorderColor="FFFFFF" divLineColor="FFFFFF" divLineAlpha="100" numVDivlines="10" vDivLineisDashed="1" showAlternateVGridColor="1" lineColor="BBDA00" anchorRadius="4" anchorBgColor="BBDA00" anchorBorderColor="FFFFFF" anchorBorderThickness="2" showValues="0" numberSuffix="%" toolTipBgColor="406181" toolTipBorderColor="406181" alternateHGridAlpha="5">\n\
\n\
	<set label="Jan" value="34" />\n\
	<set label="Feb" value="44" />\n\
	<set label="Mar" value="48" />\n\
	<set label="Apr" value="54" />\n\
	<set label="May" value="60" />\n\
	<set label="Jun" value="70" />\n\
	<set label="Jul" value="58" />\n\
	<set label="Aug" value="62" />\n\
	<set label="Sep" value="54" />\n\
	<set label="Oct" value="45" />\n\
	<set label="Nov" value="39" />\n\
	<set label="Dec" value="23" />\n\
\n\
	<styles>\n\
		<definition>\n\
			<style name="LineShadow" type="shadow" color="333333" distance="6"/>\n\
		</definition>\n\
\n\
		<application>\n\
			<apply toObject="DATAPLOT" styles="LineShadow" />\n\
		</application>	\n\
	</styles>\n\
</chart>';
