var dataString ='<chart showvalues="0" caption="Software Testing Report" xaxisname="Type of Bugs" pyaxisname="No of Bugs">\n\
\n\
  <set value="205" label="GUI"/>\n\
  <set value="165" label="Functional"/>\n\
  <set value="85" label="Navigation"/>\n\
  <set value="62" label="Cross Platform"/>\n\
  <set value="73" label="Hardware"/>\n\
  <set value="131" label="Runtime"/>\n\
  <set value="109" label="Load Condition"/>\n\
 \n\
</chart>';