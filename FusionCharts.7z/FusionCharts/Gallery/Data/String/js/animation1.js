var dataString ='<chart showvalues="0"  bgcolor="FFFFFF" showalternatehgridcolor="0" numdivlines="0" showyaxisvalues="0" plotgradientcolor="" showplotborder="0" showshadow="1" showborder="1" canvasborderalpha="0" canvasbordercolor="800080" canvasbgratio="0" canvasbgalpha="100" bordercolor="8F8F8F" borderalpha="50" bgratio="0" bgalpha="50" >\n\
 <set value="490000" color="64810A"  label="China"/>\n\
 <set value="340000" color="7B9F0C"  label="USA"/>\n\
 <set value="160000" color="90BC0E"  label="Brazil"/>\n\
 <set value="220000" color="B7D702"  label="Spain"/>\n\
 <set value="123000" color="DFEB55"  label="India"/>\n\
 <styles>\n\
 <definition>\n\
 <style name="Animation_0" type="ANIMATION" duration="2" start="0" param="_y"/>\n\
 <style name="Animation_1" type="ANIMATION" duration="2" start="0" param="_x" easing="Regular"/>\n\
 </definition>\n\
 <application>\n\
 <apply toObject="DATALABELS" styles="Animation_0"/>\n\
 <apply toObject="DATAPLOT" styles="Animation_1"/>\n\
 </application>\n\
 </styles>\n\
 </chart>';
