var dataString ='<chart palette="5" caption="Product Sales" xAxisName="Month" yAxisName="Sales" numberPrefix="$"  rotateValues="1" placeValuesInside="1" forceYAxisValueDecimals="1"  yAxisValueDecimals="2">\n\
	<categories>\n\
		<category label="January" />\n\
		<category label="February" />\n\
		<category label="March" />\n\
		<category label="April" />\n\
		<category label="May" />\n\
		<category label="June" />\n\
	</categories>\n\
	<dataset seriesname="Product A" color="F0807F" showValues="1">\n\
		<set value="8343" />\n\
		<set value="6983" />\n\
		<set value="7658" />\n\
		<set value="8345" />\n\
		<set value="8195" />\n\
		<set value="7684"/>\n\
	</dataset>\n\
	<dataset seriesname="Product B" color="F1C7D2"  showValues="1">\n\
		<set value="2446" />\n\
		<set value="3935" />\n\
		<set value="3452"  />\n\
		<set value="4424" />\n\
		<set value="4925" />\n\
		<set value="4328" />\n\
	</dataset>\n\
</chart>';
