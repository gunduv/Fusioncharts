var dataString ='<chart showvalues="0" caption="Customer Complain Report" stack100percent="0" canvasbgangle="0" canvasborderthickness="2" chartleftmargin="15" chartrightmargin="5"  basefontsize="10" outcnvbasefontsize="11" bgcolor="FFFFFF"  showcumulativeline="1"  linecolor="D3AF1D" showplotborder="1" plotgradientcolor=""  plotbordercolor="EFEFEF" showcanvasbg="1" showcanvasbase="1"  canvasbgcolor="FFFFFF" canvasbgalpha="100" canvasbasecolor="D3DBCA" showalternatehgridcolor="0" showborder="1" canvasborderalpha="0" divlinealpha="0" showshadow="1" plotfillangle="45" plotfillratio="" plotborderdashed="0" plotborderdashlen="1" anchorradius="3" anchorbgcolor="FFFFFF" anchorborderthickness="3" linethickness="3">\n\
	<set value="230" color="7E3918"  label="Poor Quality"/>\n\
	<set value="185" color="7E3918"  label="Incorrect Pricing"/>\n\
	<set value="115" color="7E3918"  label="Confusing Layout"/>\n\
	<set value="72" color="7E3918"  label="Parking Difficulties"/>\n\
	<set value="83" color="7E3918"  label="Limited Size"/>\n\
	<set value="64" color="7E3918"  label="Others"/>\n\
</chart>';
