var dataString ='<chart animation="1" showvalues="0" canvasborderalpha="0" bgcolor="FFFFFF" bgratio="0" bgalpha="50" showalternatehgridcolor="0" numdivlines="0" showyaxisvalues="0" showlegend="1" drawanchors="0" bordercolor="970000" borderalpha="31" stack100percent="0" linethickness="3" basefontsize="12" >\n\
 <categories>\n\
  <category label="Jan"/>\n\
  <category label="Feb"/>\n\
  <category label="Mar"/>\n\
  <category label="Apr"/>\n\
  <category label="May"/>\n\
 </categories>\n\
 <dataset seriesName="2008"  color="CE0000">\n\
  <set value="235"/>\n\
  <set value="125"/>\n\
  <set value="264"/>\n\
  <set value="234"/>\n\
  <set value="389"/>\n\
 </dataset>\n\
 <dataset seriesName="2007" color="7F7F7F" >\n\
  <set value="190"/>\n\
  <set value="107"/>\n\
  <set value="203"/>\n\
  <set value="145"/>\n\
  <set value="175"/>\n\
 </dataset>\n\
 <styles><definition>\n\
 <style type="Shadow" name="Shadow_0" Distance="8" Color="8F8F8F" Alpha="50" blurY="5"/>\n\
 </definition><application><apply toObject="DATAPLOT" styles="Shadow_0"/></application></styles></chart>';
