var dataString ='<chart caption="Data Ingestion Summary" showLabels="1" showvalues="0" decimals="0" numberPrefix="">\n\
<categories><category label="Siebel Row" /><category label="Siebel Serice" /><category label="Customer Master" /><category label="iRemarket" /><category label="Infolease" /></categories>\n\
<dataset seriesName="Source" color="AFD8F8" showValues="0">\n\
<set value="900" />\n\
<set value="900" />\n\
<set value="180" />\n\
<set value="3500" />\n\
<set value="600" />\n\
</dataset>\n\
<dataset seriesName="Ingested" color="8BBA00" showValues="0">\n\
<set value="95" />\n\
<set value="89" />\n\
<set value="43" />\n\
<set value="2800" />\n\
<set value="400" />\n\
</dataset>\n\
<dataset seriesName="Stage" color="F6BD0F" showValues="0">\n\
<set value="95" />\n\
<set value="89" />\n\
<set value="43" />\n\
<set value="2800" />\n\
<set value="400" />\n\
</dataset>\n\
<dataset seriesName="Raw" color="8BBA00" showValues="0">\n\
<set value="95" />\n\
<set value="89" />\n\
<set value="43" />\n\
<set value="2800" />\n\
<set value="400" />\n\
</dataset>\n\
<dataset seriesName="Arcive" color="8BBA00" showValues="0">\n\
<set value="95" />\n\
<set value="89" />\n\
<set value="43" />\n\
<set value="2800" />\n\
<set value="400" />\n\
</dataset>\n\
</chart>';