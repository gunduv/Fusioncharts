var dataString ='<chart caption="Market Activity" yAxisName="Listings" showvalues="0" areaOverColumns="0" stack100Percent="1" showPercentValues="1" >\n\
\n\
	<categories>\n\
		<category label="Jan" />\n\
		<category label="Feb" />\n\
		<category label="Mar" />\n\
		<category label="Apr" />\n\
		<category label="May" />\n\
		<category label="Jun" />\n\
		<category label="Jul" />\n\
		<category label="Aug" />\n\
		<category label="Sep" />\n\
		<category label="Oct" />\n\
		<category label="Nov" />\n\
		<category label="Dec" />\n\
	</categories>\n\
\n\
	<dataset seriesName="New Listings" color="FBAB35" renderAs="Area" alpha="80">\n\
		<set value="370" />\n\
		<set value="401" />\n\
		<set value="342" />\n\
		<set value="370" />\n\
		<set value="414" />\n\
		<set value="385" />\n\
		<set value="400" />\n\
		<set value="456" />\n\
		<set value="340" />\n\
		<set value="390" />\n\
		<set value="332" />\n\
		<set value="401" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Re-list" color="DA3608" renderAs="line">\n\
		<set value="325" />\n\
		<set value="305" />\n\
		<set value="295" />\n\
		<set value="345" />\n\
		<set value="285" />\n\
		<set value="315" />\n\
		<set value="295" />\n\
		<set value="335" />\n\
		<set value="300" />\n\
		<set value="320" />\n\
		<set value="285" />\n\
		<set value="260" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Sold" color="015887">\n\
		<set value="155" />\n\
		<set value="135" />\n\
		<set value="125" />\n\
		<set value="175" />\n\
		<set value="115" />\n\
		<set value="145" />\n\
		<set value="125" />\n\
		<set value="165" />\n\
		<set value="130" />\n\
		<set value="150" />\n\
		<set value="115" />\n\
		<set value="90" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Withdrawn" color="78AE1C">\n\
		<set value="76" />\n\
		<set value="85" />\n\
		<set value="64" />\n\
		<set value="105" />\n\
		<set value="56" />\n\
		<set value="78" />\n\
		<set value="56" />\n\
		<set value="105" />\n\
		<set value="80" />\n\
		<set value="100" />\n\
		<set value="67" />\n\
		<set value="82" />\n\
	</dataset>\n\
\n\
</chart>';