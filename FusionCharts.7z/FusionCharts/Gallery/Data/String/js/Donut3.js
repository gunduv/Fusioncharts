var dataString ='<chart caption="Industrial Growth Rate" subcaption="(Country)" palette="4" decimals="0" enableSmartLabels="1" enableRotation="0" bgAngle="360" showBorder="1" startingAngle="70" >\n\
            <set label="France" value="17"  />\n\
            <set label="India" value="12" />\n\
            <set label="Brazil" value="18" />\n\
            <set label="USA" value="8" isSliced="1"/>\n\
            <set label="Australia" value="10" isSliced="1"/>\n\
            <set label="Japan" value="16" isSliced="1"/>\n\
            <set label="England" value="11" />\n\
            <set label="Nigeria" value="12" />\n\
	    <set label="Italy" value="8" />\n\
            <set label="China" value="10" />\n\
            <set label="Canada" value="19"/>\n\
            <set label="Germany" value="15"/>\n\
</chart>';