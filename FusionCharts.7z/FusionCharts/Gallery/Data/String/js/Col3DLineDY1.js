var dataString ='<chart palette="1" caption="Sales" showLabels="1" showvalues="0" numberPrefix="$" sYAxisValuesDecimals="2" connectNullData="0" PYAxisName="Revenue" SYAxisName="Quantity"  numDivLines="4" formatNumberScale="0">\n\
<categories>\n\
<category label="March" />\n\
<category label="April" />\n\
<category label="May" />\n\
<category label="June" />\n\
<category label="July" />\n\
</categories>\n\
<dataset seriesName="Product A" color="AFD8F8" showValues="0">\n\
<set value="25601.34" />\n\
<set value="20148.82" />\n\
<set value="17372.76" />\n\
<set value="35407.15" />\n\
<set value="38105.68" />\n\
</dataset>\n\
<dataset seriesName="Product B" color="F6BD0F" showValues="0" >\n\
<set value="57401.85" /> \n\
<set value="41941.19" />\n\
<set value="45263.37" />\n\
<set value="117320.16" />\n\
<set value="114845.27" dashed="1"/>\n\
</dataset>\n\
<dataset seriesName="Total Quantity" color="8BBA00" showValues="0" parentYAxis="S" >\n\
<set value="45000" />\n\
<set value="44835" />\n\
<set value="42835" />\n\
<set value="77557" />\n\
<set value="92633" />\n\
</dataset>\n\
</chart>';