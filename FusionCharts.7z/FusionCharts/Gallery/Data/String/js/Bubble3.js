var dataString ='<chart bgAlpha="0" canvasBgAlpha="0" xAxisName="Price (Bt./kg.)" yAxisName="Original Cost (Bt./kg.)" numDivLines="4" showAlternateVGridColor="1" AlternateVGridAlpha="30" numberPrefix="$">\n\
<categories verticalLineColor="666666" verticalLineAlpha="20">\n\
<category label="0" x="0" />\n\
<category label="5" x="5" sL="1"/>\n\
<category label="10" x="10" sL="1"/>\n\
<category label="15" x="15" sL="1"/>\n\
<category label="20" x="20" sL="1"/>\n\
<category label="25" x="25" sL="1"/>\n\
<category label="30" x="30" sL="1"/>\n\
<category label="35" x="35" sL="1"/>\n\
<category label="40" x="40" sL="1"/>\n\
<category label="45" x="45" sL="1"/>\n\
</categories>\n\
<dataSet color="ff5904" seriesName="1996" showValues="0">\n\
<set x="30" y="35" z="116" name="Mango" />\n\
<set x="42" y="60" z="99" name="Apple" />\n\
<set x="8" y="15" z="33" name="Orange"/>\n\
<set x="22" y="30" z="72" name="Strawberry"/>\n\
<set x="18" y="20" z="55" name="Kiwi"/>\n\
<set x="25" y="41" z="58" name="Tomato"/>\n\
<set x="12" y="17" z="80" name="Cucumber"/>\n\
<set x="20" y="30" z="105" name="Potato"/>\n\
</dataSet>\n\
\n\
<dataSet color="4371AB" seriesName="1997" >\n\
<set x="14" y="35" z="116" name="Mango"/>\n\
<set x="22" y="20" z="99" name="Apple"/>\n\
<set x="28" y="25" z="33" name="Orange"/>\n\
<set x="32" y="20" z="72" name="Strawberry"/>\n\
<set x="38" y="20" z="55" name="Kiwi"/>\n\
<set x="5" y="21" z="58" name="Tomato"/>\n\
<set x="2" y="27" z="80" name="Cucumber"/>\n\
<set x="12" y="20" z="105" name="Potato"/>\n\
</dataSet>\n\
\n\
<trendlines>\n\
	<line Value="50" isTrendZone="0" displayValue="Trend"/>\n\
</trendlines>\n\
</chart>';