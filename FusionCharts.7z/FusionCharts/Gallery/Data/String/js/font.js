var dataString ='<chart showvalues="0" caption="Monthly Unit Sales"  showyaxisvalues="0" showlegend="0" canvasbasecolor="CFCFCF" canvasbgratio="0" canvasbgalpha="100" showcanvasbg="0" showborder="0" canvasbasedepth="4" divlinecolor="FFFFFF" >\n\
 <categories>\n\
  <category label="Jan"/>\n\
  <category label="Feb"/>\n\
  <category label="Mar"/>\n\
  <category label="Apr"/>\n\
  <category label="May"/>\n\
 </categories>\n\
 <dataset seriesName="2008" color="CE0000">\n\
  <set value="235"/>\n\
  <set value="125"/>\n\
  <set value="264"/>\n\
  <set value="234"/>\n\
  <set value="389"/>\n\
 </dataset>\n\
 <dataset seriesName="2007" color="5F5F5F" >\n\
  <set value="190"/>\n\
  <set value="107"/>\n\
  <set value="203"/>\n\
  <set value="145"/>\n\
  <set value="175"/>\n\
 </dataset>\n\
<styles><definition><style name="Font_0" type="font" font="Tahoma" size="16" underline="1"  color="930000"  /><style name="Font_1" type="font" font="Times" size="22" color="4F4F4F" bold="0" align="right" Italic="1" bgcolor="DFDFDF" bordercolor="D0D0D0" /></definition><application><apply toObject="DATALABELS" styles="Font_0"/><apply toObject="CAPTION" styles="Font_1"/></application></styles>\n\
</chart>';
