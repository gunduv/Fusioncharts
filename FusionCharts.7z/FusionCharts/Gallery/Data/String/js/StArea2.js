var dataString ='<chart caption="Site hits per hour" subCaption="In Thousands" showValues="0" numVDivLines="22" rotateNames="1" areaAlpha="90" labelStep="2">\n\
\n\
	<categories >\n\
		<category label="00:00" />\n\
		<category label="01:00" />\n\
		<category label="02:00" />\n\
		<category label="03:00" />\n\
		<category label="04:00" />\n\
		<category label="05:00" />\n\
		<category label="06:00" />\n\
		<category label="07:00" />\n\
		<category label="08:00" />\n\
		<category label="09:00" />\n\
		<category label="10:00" />\n\
		<category label="11:00" />\n\
		<category label="12:00" />\n\
		<category label="13:00" />\n\
		<category label="14:00" />\n\
		<category label="15:00" />\n\
		<category label="16:00" />\n\
		<category label="17:00" />\n\
		<category label="18:00" />\n\
		<category label="19:00" />\n\
		<category label="20:00" />\n\
		<category label="21:00" />\n\
		<category label="22:00" />\n\
		<category label="23:00" />\n\
	</categories>\n\
\n\
	<dataset seriesName="Sat" color="0080C0" areaBorderColor="0080C0">\n\
		<set value="36" />\n\
		<set value="71" />\n\
		<set value="85" />\n\
		<set value="92" />\n\
		<set value="101" />\n\
		<set value="116" />\n\
		<set value="164" />\n\
		<set value="180" />\n\
		<set value="192" />\n\
		<set value="262" />\n\
		<set value="319" />\n\
		<set value="489" />\n\
		<set value="633" />\n\
		<set value="904" />\n\
		<set value="1215" />\n\
		<set value="1358" />\n\
		<set value="1482" />\n\
		<set value="1666" />\n\
		<set value="1811" />\n\
		<set value="2051" />\n\
		<set value="2138" />\n\
		<set value="2209" />\n\
		<set value="2247" />\n\
		<set value="2301" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Sun" color="008040" areaBorderColor="008040">\n\
		<set value="23" />\n\
		<set value="40" />\n\
		<set value="62" />\n\
		<set value="118" />\n\
		<set value="130" />\n\
		<set value="139" />\n\
		<set value="158" />\n\
		<set value="233" />\n\
		<set value="297" />\n\
		<set value="379" />\n\
		<set value="503" />\n\
		<set value="687" />\n\
		<set value="746" />\n\
		<set value="857" />\n\
		<set value="973" />\n\
		<set value="1125" />\n\
		<set value="1320" />\n\
		<set value="1518" />\n\
		<set value="1797" />\n\
		<set value="1893" />\n\
		<set value="2010" />\n\
		<set value="2057" />\n\
		<set value="2166" />\n\
		<set value="2197" />\n\
	</dataset>\n\
	<dataset seriesName="Mon" color="808080" areaBorderColor="808080">\n\
		<set value="37" />\n\
		<set value="45" />\n\
		<set value="70" />\n\
		<set value="79" />\n\
		<set value="168" />\n\
		<set value="337" />\n\
		<set value="374" />\n\
		<set value="431" />\n\
		<set value="543" />\n\
		<set value="784" />\n\
		<set value="1117" />\n\
		<set value="1415" />\n\
		<set value="2077" />\n\
		<set value="2510" />\n\
		<set value="3025" />\n\
		<set value="3383" />\n\
		<set value="3711" />\n\
		<set value="4016" />\n\
		<set value="4355" />\n\
		<set value="4751" />\n\
		<set value="5154" />\n\
		<set value="5475" />\n\
		<set value="5696" />\n\
		<set value="5801" />\n\
	</dataset>\n\
	<dataset seriesName="Tue" color="800080" areaBorderColor="800080">\n\
		<set value="54" />\n\
		<set value="165" />\n\
		<set value="175" />\n\
		<set value="190" />\n\
		<set value="212" />\n\
		<set value="241" />\n\
		<set value="308" />\n\
		<set value="401" />\n\
		<set value="481" />\n\
		<set value="851" />\n\
		<set value="1250" />\n\
		<set value="2415" />\n\
		<set value="2886" />\n\
		<set value="3252" />\n\
		<set value="3673" />\n\
		<set value="4026" />\n\
		<set value="4470" />\n\
		<set value="4813" />\n\
		<set value="4961" />\n\
		<set value="5086" />\n\
		<set value="5284" />\n\
		<set value="5391" />\n\
		<set value="5657" />\n\
		<set value="5847" />\n\
	</dataset>\n\
	<dataset seriesName="Wed" color="FF8040" areaBorderColor="FF8040">\n\
		<set value="111" />\n\
		<set value="120" />\n\
		<set value="128" />\n\
		<set value="140" />\n\
		<set value="146" />\n\
		<set value="157" />\n\
		<set value="190" />\n\
		<set value="250" />\n\
		<set value="399" />\n\
		<set value="691" />\n\
		<set value="952" />\n\
		<set value="1448" />\n\
		<set value="1771" />\n\
		<set value="2316" />\n\
		<set value="2763" />\n\
		<set value="3149" />\n\
		<set value="3637" />\n\
		<set value="4015" />\n\
		<set value="4262" />\n\
		<set value="4541" />\n\
		<set value="4837" />\n\
		<set value="5016" />\n\
		<set value="5133" />\n\
		<set value="5278" />\n\
	</dataset>\n\
	<dataset seriesName="Thu" color="FFFF00" areaBorderColor="FFFF00">\n\
		<set value="115" />\n\
		<set value="141" />\n\
		<set value="175" />\n\
		<set value="189" />\n\
		<set value="208" />\n\
		<set value="229" />\n\
		<set value="252" />\n\
		<set value="440" />\n\
		<set value="608" />\n\
		<set value="889" />\n\
		<set value="1334" />\n\
		<set value="1637" />\n\
		<set value="2056" />\n\
		<set value="2600" />\n\
		<set value="3070" />\n\
		<set value="3451" />\n\
		<set value="3918" />\n\
		<set value="4140" />\n\
		<set value="4296" />\n\
		<set value="4519" />\n\
		<set value="4716" />\n\
		<set value="4881" />\n\
		<set value="5092" />\n\
		<set value="5249" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Fri" color="FF0080" areaBorderColor="FF0080">\n\
		<set value="98" />\n\
		<set value="1112" />\n\
		<set value="1192" />\n\
		<set value="1219" />\n\
		<set value="1264" />\n\
		<set value="1282" />\n\
		<set value="1365" />\n\
		<set value="1433" />\n\
		<set value="1559" />\n\
		<set value="1823" />\n\
		<set value="1867" />\n\
		<set value="2198" />\n\
		<set value="1112" />\n\
		<set value="1192" />\n\
		<set value="1219" />\n\
		<set value="2264" />\n\
		<set value="2282" />\n\
		<set value="2365" />\n\
		<set value="2433" />\n\
		<set value="2559" />\n\
		<set value="2823" />\n\
		<set value="2867" />\n\
		<set value="2867" />\n\
		<set value="2867" />\n\
	</dataset>\n\
\n\
</chart>';
