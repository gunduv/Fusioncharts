var dataString ='<chart caption="Marketing Expenses" bgColor="FFFFFF,CCCCCC" showPercentageValues="1" plotBorderColor="FFFFFF" numberPrefix="$" isSmartLineSlanted="0" showValues="0" showLabels="0" showLegend="1">\n\
	<set value="212000" label="Banners" color="99CC00" alpha="60"/>\n\
	<set value="96800" label="Print Ads" color="333333" alpha="60"/>\n\
	<set value="26400" label="Service" color="99CC00" alpha="30" />\n\
	<set value="29300" label="Others" color="333333" alpha="30"/>\n\
</chart>';
