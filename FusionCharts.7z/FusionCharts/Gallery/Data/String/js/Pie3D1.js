var dataString ='<chart caption="Top 5 Employees for 1996" palette="2" animation="1" \n\
subCaption="(Click to slice out or right click to choose rotation mode)" YAxisName="Sales Achieved" showValues="0" \n\
numberPrefix="$" formatNumberScale="0" showPercentInToolTip="0" showLabels="0" showLegend="1">\n\
<set label="Leverling" value="100524" isSliced="0" />\n\
<set label="Fuller" value="87790" isSliced="0" />\n\
<set label="Davolio" value="81898" isSliced="0" />\n\
<set label="Peacock" value="76438" isSliced="0" />\n\
<set label="King" value="57430" isSliced="0" />\n\
<styles>\n\
<definition>\n\
<style type="font" name="CaptionFont" color="666666" size="15" />\n\
<style type="font" name="SubCaptionFont" bold="0" />\n\
</definition>\n\
<application>\n\
<apply toObject="caption" styles="CaptionFont" />\n\
<apply toObject="SubCaption" styles="SubCaptionFont" />\n\
</application>\n\
</styles>\n\
</chart>';