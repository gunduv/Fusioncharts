var dataString ='<chart caption="Fruit Production for March" subCaption="(in Millions)" yAxisName="Quantity" xAxisName="Fruit" alternateVGridColor="AFD8F8" baseFontColor="114B78" toolTipBorderColor="114B78" toolTipBgColor="E7EFF6" plotBorderDashed="1" plotBorderDashLen="2" plotBorderDashGap="2"  useRoundEdges="1" showBorder="0" bgColor="FFFFFF,FFFFFF">\n\
	<set label="Orange" value="23" color="AFD8F8"/> \n\
	<set label="Apple" value="12" color="F6BD0F"/> \n\
	<set label="Banana" value="17" color="8BBA00"/> \n\
	<set label="Mango" value="14"  color="A66EDD"/> \n\
	<set label="Litchi" value="12"  color="F984A1"/>\n\
</chart>';
