var dataString ='<chart showvalues="0" caption="Software Testing Report" xaxisname="Type of Bugs" stack100percent="0" pyaxisname="No of Bugs" canvasbgangle="0" canvasborderthickness="2" chartleftmargin="10" chartrightmargin="5" charttopmargin="18" chartbottommargin="18" captionpadding="15" basefontsize="10" outcnvbasefontsize="11" zeroplanealpha="80" zeroplanethickness="2" bgcolor="FFFFFF" linecolor="3F3F3F" showplotborder="0" plotgradientcolor="" linethickness="3" linedashed="0" plotbordercolor="7F7F7F" showcanvasbg="0" showcanvasbase="1" canvasbasedepth="7" canvasbgdepth="1" canvasbgcolor="EFEFEF" canvasbgalpha="100" canvasbasecolor="D3DBCA" anchorradius="4" anchorbgcolor="FFFFFF" outcnvbasefont="Tahoma">\n\
 <set value="205" color="1A2CA6"  label="GUI"/>\n\
 <set value="165" color="1A2CA6"  alpha="90" alpha_cc="90" label="Functional"/>\n\
 <set value="85" color="1A2CA6"  alpha="75" alpha_cc="75" label="Navigation"/>\n\
 <set value="62" color="1A2CA6"  alpha="65" alpha_cc="65" label="Cross Platform"/>\n\
 <set value="73" color="1A2CA6"  alpha="70" alpha_cc="70" label="Hardware"/>\n\
 <set value="131" color="1A2CA6"  alpha="85" alpha_cc="85" label="Runtime"/>\n\
 <set value="109" color="1A2CA6"  alpha="80" alpha_cc="80" label="Load Condition"/>\n\
</chart>';
