var dataString ='<chart caption="Alphabet Usage in a Novel" formatNumberScale="0">\n\
<set label="B" value="51852" />\n\
<set label="C" value="88168" />\n\
<set label="D" value="73897" />\n\
<set label="E" value="93933" />\n\
<set label="F" value="19289" />\n\
<set label="G" value="79623" />\n\
<set label="H" value="48262" />\n\
<set label="I" value="29162" />\n\
<set label="J" value="96878" />\n\
<set label="K" value="81241" />\n\
<set label="L" value="40652" isSliced="1"/>\n\
<set label="M" value="37581" isSliced="1"/>\n\
<set label="N" value="2882" />\n\
<set label="O" value="746" />\n\
<set label="P" value="7155" />\n\
<set label="Q" value="12072" />\n\
<set label="R" value="45608" />\n\
<set label="S" value="72570" />\n\
<set label="T" value="44799" />\n\
<set label="U" value="71887" />\n\
<set label="V" value="78170" />\n\
</chart>';