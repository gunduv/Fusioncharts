var dataString ='<chart palette="3" numberPrefix="$" is3D="1" animation="1" clipBubbles="1" xAxisMaxValue="100" showPlotBorder="0" xAxisName="Stickiness" yAxisName="Cost Per Service" chartRightMargin="30">\n\
<categories>\n\
<category label="0%" x="0" />\n\
<category label="20%" x="20" showVerticalLine="1"/>\n\
<category label="40%" x="40" showVerticalLine="1"/>\n\
<category label="60%" x="60" showVerticalLine="1"/>\n\
<category label="80%" x="80" showVerticalLine="1"/>\n\
<category label="100%" x="100" showVerticalLine="1"/>\n\
</categories>\n\
<dataSet showValues="0">\n\
<set x="30" y="1.3" z="116"  name="Traders"/>\n\
<set x="32" y="3.5" z="99" name="Farmers"/>\n\
<set x="8" y="2.1" z="33" name="Individuals"/>\n\
<set x="62" y="2.5" z="72" name="Medium Business Houses"/>\n\
<set x="78" y="2.3" z="55" name="Corporate Group A"/>\n\
<set x="75" y="1.4" z="58" name="Corporate Group C"/>\n\
<set x="68" y="3.7" z="80" name="HNW Individuals"/>\n\
<set x="50" y="2.1" z="105" name="Small Business Houses"/>\n\
</dataSet>\n\
<trendlines>\n\
	<line startValue="2.5" isTrendZone="0" displayValue="Median Cost" color="0372AB"/>\n\
</trendlines>\n\
<vTrendlines>\n\
	<line startValue="0" endValue="60" isTrendZone="1" displayValue="Potential Wins" color="663333" alpha="10"/>\n\
<line startValue="60" endValue="100" isTrendZone="1" displayValue="Cash Cows" color="990099" alpha="5"/>\n\
\n\
</vTrendlines>\n\
</chart>';