var dataString ='<chart  showvalues="0" caption="Quarterly Website  Visits (2010)" xaxisname="No of Visitor" yaxisname="Monthly share" animation="1" stack100percent="0" canvasbgangle="0" canvasborderthickness="2" chartleftmargin="5" chartrightmargin="15" charttopmargin="10" chartbottommargin="20" captionpadding="10" xaxisnamepadding="5" yaxisnamepadding="5" yaxisvaluespadding="2" labelpadding="3" basefontsize="13" outcnvbasefontsize="12" zeroplanealpha="80" zeroplanethickness="2" bgcolor="FFFFFF" bgalpha="100" showxaxispercentvalues="0" usepercentdistribution="1" plotgradientcolor="" basefont="Calibri" canvasbgcolor="FFFFFF" showalternatehgridcolor="0" alternatehgridcolor="FEEFED" divlinealpha="0" >\n\
	<categories>\n\
		<category label="Site A" widthpercent="40"/>\n\
		<category label="Site B" widthpercent="15"/>\n\
		<category label="Site C" widthpercent="15"/>\n\
		<category label="Site D" widthpercent="15"/>\n\
		<category label="Site E" widthpercent="15"/>\n\
	</categories>\n\
	<dataset seriesName="Jan" color="76EFB8" >\n\
		<set value="10548"/>\n\
		<set value="9550"/>\n\
		<set value="9001"/>\n\
		<set value="8120"/>\n\
		<set value="7845"/>\n\
	</dataset>\n\
	<dataset seriesName="Feb"  color="92BACF">\n\
		<set value="12500"/>\n\
		<set value="10800"/>\n\
		<set value="9800"/>\n\
		<set value="9080"/>\n\
		<set value="8100"/>\n\
	</dataset>\n\
	<dataset seriesName="Mar" color="DBAEEE" >\n\
		<set value="13800"/>\n\
		<set value="11930"/>\n\
		<set value="10360"/>\n\
		<set value="10769"/>\n\
		<set value="9077"/>\n\
	</dataset>\n\
	</chart>';
