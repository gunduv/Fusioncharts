var dataString ='<chart caption="Visits from search engines" showValues="0" showColumnShadow="0" sNumberSuffix="%">\n\
\n\
	<categories>\n\
		<category label="Jan" />\n\
		<category label="Feb" />\n\
		<category label="Mar" />\n\
		<category label="Apr" />\n\
		<category label="May" />\n\
		<category label="Jun" />\n\
		<category label="Jul" />\n\
		<category label="Aug" />\n\
		<category label="Sep" />\n\
		<category label="Oct" />\n\
		<category label="Nov" />\n\
		<category label="Dec" />\n\
	</categories>\n\
\n\
	<dataset seriesName="Google">\n\
		<set value="3040" />\n\
		<set value="2794" />\n\
		<set value="3026" />\n\
		<set value="3341" />\n\
		<set value="2800" />\n\
		<set value="2507" />\n\
		<set value="3701" />\n\
		<set value="2671" />\n\
		<set value="2980" />\n\
		<set value="2041" />\n\
		<set value="1813" />\n\
		<set value="1691" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Yahoo">\n\
		<set value="1200" />\n\
		<set value="1124" />\n\
		<set value="1006" />\n\
		<set value="921" />\n\
		<set value="1500" />\n\
		<set value="1007" />\n\
		<set value="921" />\n\
		<set value="971" />\n\
		<set value="1080" />\n\
		<set value="1041" />\n\
		<set value="1113" />\n\
		<set value="1091" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="MSN">\n\
		<set value="600" />\n\
		<set value="724" />\n\
		<set value="806" />\n\
		<set value="621" />\n\
		<set value="700" />\n\
		<set value="907" />\n\
		<set value="821" />\n\
		<set value="671" />\n\
		<set value="880" />\n\
		<set value="641" />\n\
		<set value="913" />\n\
		<set value="691" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Percent of total hits" parentYAxis="S" lineThickness="4" color="993300">\n\
		<set value="96.5" />\n\
		<set value="77.1" />\n\
		<set value="73.2" />\n\
		<set value="61.1" />\n\
		<set value="70.0" />\n\
		<set value="60.7" />\n\
		<set value="62.1" />\n\
		<set value="75.1" />\n\
		<set value="80.0" />\n\
		<set value="54.1" />\n\
		<set value="51.3" />\n\
		<set value="59.1" />\n\
	</dataset>\n\
</chart>';
