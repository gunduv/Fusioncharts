var dataString ='<chart caption="Product Sales - 2005" bgAlpha="30,100" bgAngle="45" pieYScale="50" startingAngle="175"  smartLineColor="7D8892" smartLineThickness="2">\n\
\n\
	<set value="243" label="USA" color="A53838"  />\n\
	<set value="207" label="UK"  color="7D8892" />\n\
	<set value="82" label="Canada" color="C3CACA"/>\n\
	<set value="65" label="France"  color="B2D2DD"/>\n\
	<set value="175" label="Others"  color="507D9E"/>\n\
\n\
	<styles>\n\
\n\
		<definition>\n\
			<style name="CaptionFont" type="FONT" face="Verdana" size="11" color="7D8892" bold="1" />\n\
			<style name="LabelFont" type="FONT" color="7D8892" bold="1"/>\n\
		</definition>\n\
\n\
		<application>\n\
	        	<apply toObject="DATALABELS" styles="LabelFont" />\n\
        		<apply toObject="CAPTION" styles="CaptionFont" />\n\
		</application>\n\
\n\
	</styles>\n\
</chart>';