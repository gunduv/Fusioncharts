var dataString ='<chart caption="Business Results: 2005" yAxisName="Revenue (Millions)" canvasBgColor="FEFEFE" canvasBaseColor="FEFEFE" toolTipBgColor="DEDEBE" toolTipBorder="889E6D" divLineColor="999999" showColumnShadow="0" divLineIsDashed="1" divLineDashLen="1" divLineDashGap="2" numberPrefix="$" numberSuffix="M">\n\
\n\
	<categories>\n\
		<category label="Hardware"/>\n\
		<category label="Software" />\n\
		<category label="Service" />\n\
	</categories>\n\
\n\
	<dataset seriesname="Domestic" color="8EAC41">\n\
		<set value="84" />\n\
		<set value="207" />\n\
		<set value="116" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="International" color="607142" >\n\
		<set value="116" />\n\
		<set value="237" />\n\
		<set value="83" />\n\
	</dataset>\n\
\n\
</chart>'; 