	var dataString ='<chart showvalues="0"  showalternatehgridcolor="0" numdivlines="0" showyaxisvalues="0"  plotgradientcolor="590059" showplotborder="0" showshadow="1" showborder="1" canvasborderalpha="0" yaxisvaluespadding="10"  canvasbgalpha="5" bordercolor="8F8F8F" borderalpha="50" bgratio="0" bgalpha="20,10" canvasbgcolor="F7F0F9" basefont="Verdana" basefontsize="13" basefontcolor="9F9F9F" >\n\
 <set value="340000" color="C987DC"  label="USA"/>\n\
 <set value="160000" color="C987DC"  label="Brazil"/>\n\
 <set value="220000" color="C987DC"  label="Spain"/>\n\
 <set value="123000" color="C987DC"  label="India"/>\n\
 <styles><definition><style name="Animation_0" type="ANIMATION" duration="3" start="0" param="_y" easing="Bounce"/>\n\
 <style type="Bevel" name="Bevel_0" angle="210" Distance="40" shadowColor="5B005B" shadowAlpha="100" highlightColor="800080" highlightAlpha="61" blurY="6" Strength="4" Quality="2"/></definition>\n\
 <application>\n\
 <apply toObject="DATAPLOT" styles="Animation_0,Bevel_0"/>\n\
 </application>\n\
 </styles>\n\
 </chart>';
