var dataString ='<chart caption="Brand Winner" yAxisName="Brand Value ($ m)" xAxisName="Brand" bgColor="F1F1F1" showValues="0" canvasBorderThickness="1" canvasBorderColor="999999" plotFillAngle="330" plotBorderColor="999999" showAlternateVGridColor="1" divLineAlpha="0">\n\
	<set label="Coca-Cola" value="67000" toolText="2006 Rank: 1, Country: US"/> \n\
	<set label="Microsoft" value="56926" toolText="2006 Rank: 2, Country: US"/> \n\
	<set label="IBM" value="56201" toolText="2006 Rank: 3, Country: US"/> \n\
	<set label="GE" value="48907" toolText="2006 Rank: 4, Country: US"/> \n\
	<set label="Intel" value="32319" toolText="2006 Rank: 5, Country: US"/> \n\
	<set label="Nokia" value="30131" toolText="2006 Rank: 6, Country: Finland"/> \n\
	<set label="Toyota" value="27941" toolText="2006 Rank: 7, Country: Japan"/> \n\
	<set label="Disney" value="27848" toolText="2006 Rank: 8, Country: US"/> \n\
	<set label="McDonalds" value="27501" toolText="2006 Rank: 9, Country: US"/> \n\
	<set label="Mercedes-Benz" value="21795" toolText="2006 Rank: 10, Country: Germany"/> \n\
</chart>';