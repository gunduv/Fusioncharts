var dataString ='<chart palette="2" caption="Monthly Sales Summary Comparison"  xAxisName="Month" yAxisName="Sales" numberPrefix="$" showValues="0" stack100Percent="1" showPercentValues="1">\n\
<categories>\n\
	<category label="Jan" />\n\
	<category label="Feb" />\n\
	<category label="Mar" />\n\
	<category label="Apr" />\n\
	<category label="May" />\n\
	<category label="Jun" />\n\
	<category label="Jul" />\n\
	<category label="Aug" />\n\
	<category label="Sep" />\n\
	<category label="Oct" />\n\
	<category label="Nov" />\n\
	<category label="Dec" />\n\
</categories>\n\
<dataset seriesName="2004" color="B1D1DC" >\n\
	<set value="27400" />\n\
	<set value="29800"/>\n\
	<set value="25800" />\n\
	<set value="26800" />\n\
	<set value="29600" />\n\
	<set value="32600" />\n\
	<set value="31800" />\n\
	<set value="36700" />\n\
	<set value="29700" />\n\
	<set value="31900" />\n\
	<set value="32900" />\n\
	<set value="34800" />\n\
</dataset>\n\
<dataset seriesName="2003" color="C8A1D1" >\n\
	<set  />\n\
	<set />\n\
	<set value="4500"/>\n\
	<set value="6500"/>\n\
	<set value="7600" />\n\
	<set value="6800" />\n\
	<set value="11800" />\n\
	<set value="19700" />\n\
	<set value="21700" />\n\
	<set value="21900" />\n\
	<set value="22900" />\n\
	<set value="29800" />\n\
</dataset>\n\
</chart>'; 