var dataString ='<chart caption="Business Results" subCaption="2004 v 2005" yAxisName="Revenue (Millions)" showValues="0" useRoundEdges="1">\n\
	<categories>\n\
		<category label="Hardware"/>\n\
		<category label="Software" />\n\
		<category label="Service" />\n\
	</categories>\n\
\n\
	<dataset seriesname="2004" color="FDC12E">\n\
		<set value="124" />\n\
		<set value="247" />\n\
		<set value="156" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="2005" color="333333" >\n\
		<set value="156" />\n\
		<set value="277" />\n\
		<set value="123" />\n\
	</dataset>\n\
</chart>';