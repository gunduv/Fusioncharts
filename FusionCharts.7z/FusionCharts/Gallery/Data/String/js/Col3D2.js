﻿var dataString ='<chart caption="1996 - Top 10 Cities By Sales " palette="2" animation="1" formatNumberScale="0" numberPrefix="$" labeldisplay="ROTATE" slantLabels="1" seriesNameInToolTip="0" sNumberSuffix=" pcs." showValues="0" plotSpacePercent="0" labelDisplay="STAGGER">\n\
<set label="Graz" value="57182.9" />\n\
<set label="Cunewalde" value="42980.99" />\n\
<set label="Boise" value="42806.25" />\n\
<set label="Rio de Janeiro" value="35054.6" />\n\
<set label="London" value="26035.96" />\n\
<set label="Cork" value="22796.34" />\n\
<set label="Albuquerque" value="22355.1" />\n\
<set label="Brandenburg" value="21789.95" />\n\
<set label="Bräcke" value="21185.85" />\n\
<set label="Seattle" value="15278.9" />\n\
<styles>\n\
<definition><style type="font" name="CaptionFont" size="15" color="666666" />\n\
<style type="font" name="SubCaptionFont" bold="0" />\n\
</definition><application>\n\
<apply toObject="caption" styles="CaptionFont" />\n\
<apply toObject="SubCaption" styles="SubCaptionFont" />\n\
</application>\n\
</styles>\n\
</chart>';