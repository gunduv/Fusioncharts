var dataString ='<chart showvalues="0" caption="Market Share Analysis" subcaption="2009" numberprefix="$" xaxisname="Market Segment" yaxisname="Market Share" animation="1" stack100percent="0"  legendcaption="Manufacturer" canvasbgangle="0" canvasborderthickness="2" chartleftmargin="5" chartrightmargin="15" charttopmargin="10" chartbottommargin="20" captionpadding="10" xaxisnamepadding="5" yaxisnamepadding="5" yaxisvaluespadding="2" labelpadding="3" basefontsize="10" outcnvbasefontsize="12" zeroplanealpha="80" zeroplanethickness="2" bgcolor="CBCBCB,E9E9E9" bgalpha="10,10" showxaxispercentvalues="1" usepercentdistribution="1" plotgradientcolor="" outcnvbasefontcolor="8F8F8F" >\n\
	<categories>\n\
		<category label="Desktop" widthpercent=""/>\n\
		<category label="Laptop" widthpercent="33"/>\n\
		<category label="Notebook" widthpercent="34"/>\n\
	</categories>\n\
	<dataset seriesName="Alpha"  color="1A86D3">\n\
		<set value="335000"/>\n\
		<set value="225100"/>\n\
		<set value="164200"/>\n\
	</dataset>\n\
	<dataset seriesName="Beta"  color="91C43E">\n\
		<set value="245000"/>\n\
		<set value="198000"/>\n\
		<set value="120000"/>\n\
	</dataset>\n\
	<dataset seriesName="Gamma" color="BFBFBF" >\n\
		<set value="298000"/>\n\
		<set value="109300"/>\n\
		<set value="153600"/>\n\
	</dataset>\n\
	</chart>';
