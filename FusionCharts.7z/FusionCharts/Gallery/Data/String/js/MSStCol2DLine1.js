var dataString ='<chart caption="Annual Revenue" subcaption="In Million $"  xaxisname="Year" PYaxisname="Sales in M$" SYAxisName="Cost as % of Revenue" decimals="0" numberPrefix="$" numberSuffix="M" sNumberSuffix="%" setAdaptiveSYMin="1" showPlotBorder="1" palette="2">\n\
	<categories font="Arial" fontSize="12" fontColor="000000">\n\
		<category label="2001"/>\n\
		<category label="2002"/>\n\
		<category label="2003"/>\n\
		<category label="2004"/>\n\
		<category label="2005"/>\n\
	</categories>\n\
	<dataset>\n\
		<dataSet seriesName="Product A" color="AFD8F8" showValues="0">\n\
			<set value="30" />\n\
			<set value="26" />\n\
			<set value="29" />\n\
			<set value="31" />\n\
			<set value="34" />\n\
		</dataSet>\n\
		<dataSet seriesName="Product B" color="F6BD0F"  showValues="0">\n\
			<set value="21" />\n\
			<set value="28" />\n\
			<set value="39" />\n\
			<set value="41" />\n\
			<set value="24" />\n\
		</dataSet>	\n\
	</dataset>	\n\
	<dataSet>\n\
		<dataset seriesname="Service A" color="8BBA00" showValues="0">\n\
			<set value="27" />\n\
			<set value="25" />\n\
			<set value="28" />\n\
			<set value="26" />\n\
			<set value="10" />\n\
		</dataset>\n\
		<dataset seriesname="Service B" color="A66EDD" showValues="0">\n\
			<set value="17" />\n\
			<set value="15" />\n\
			<set value="18" />\n\
			<set value="16" />\n\
			<set value="10" />\n\
		</dataset>\n\
		<dataset seriesname="Service C" color="F984A1" showValues="0">\n\
			<set value="12" />\n\
			<set value="17" />\n\
			<set value="16" />\n\
			<set value="15" />\n\
			<set value="12" />\n\
		</dataset>		\n\
	</dataSet>\n\
	<lineSet seriesname="Cost as % of Revenue" showValues="0" lineThickness="4" >\n\
		<set value="57" />\n\
		<set value="68" />\n\
		<set value="79" />\n\
		<set value="73" />\n\
		<set value="80" />\n\
	</lineSet>\n\
\n\
</chart>';