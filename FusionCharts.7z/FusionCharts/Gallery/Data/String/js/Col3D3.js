var dataString ='<chart caption="Decline in Net Interest Margins of Banks (1995-2005)" subCaption="(in Percentage %)" yAxisName="Points" xAxisName="Country" divLineColor="FFFFFF" numberSuffix="%" labelDisplay="Stagger" numDivLines="3">\n\
	\n\
	<set label="Spain" value="-1.33" color="F6BD0F" /> \n\
	<set label="Germany" value="-0.27" color="FF6600" /> \n\
	<set label="France" value="0.40" color="8BBA00"/> \n\
	<set label="Italy" value="1.6" color="F984A1" /> \n\
	<set label="Holland" value="-1.2" color="A66EDD"/> \n\
	<set label="Denmark" value="-2.2" color="B2FF66" /> \n\
	<set label="Sweden" value="3.2" color="AFD8F8" /> \n\
\n\
	<styles>\n\
		<definition>\n\
			<style name="DivLineGlow" type="glow" color="FFFFFF" alpha="50"/>\n\
			<style name="myCaptionFont" type="font" align="right"/>\n\
		</definition>\n\
		<application>\n\
			<apply toObject="DIVLINES" styles="DivLineGlow" />\n\
			<apply toObject="subCaption" styles="myCaptionFont" />\n\
		</application>	\n\
	</styles>\n\
</chart>';