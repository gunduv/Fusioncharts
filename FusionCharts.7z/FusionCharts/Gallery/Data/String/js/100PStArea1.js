var dataString ='<chart caption="Visits from search engines" showValues="0" plotGradientColor="999999" plotFillAlpha="95" plotBorderColor="FFFFFF"  formatNumberScale="0" stack100Percent="1" showPercentValues="1">\n\n\
\n\
	<categories>\n\
		<category label="Jan" />\n\
		<category label="Feb" />\n\
		<category label="Mar" />\n\
		<category label="Apr" />\n\
		<category label="May" />\n\
		<category label="Jun" />\n\
		<category label="Jul" />\n\
		<category label="Aug" />\n\
		<category label="Sep" />\n\
		<category label="Oct" />\n\
		<category label="Nov" />\n\
		<category label="Dec" />\n\
	</categories>\n\
\n\
	<dataset seriesName="Google">\n\
		<set value="5040" />\n\
		<set value="4794" />\n\
		<set value="5026" />\n\
		<set value="5341" />\n\
		<set value="4800" />\n\
		<set value="4507" />\n\
		<set value="5701" />\n\
		<set value="4671" />\n\
		<set value="4980" />\n\
		<set value="4041" />\n\
		<set value="3813" />\n\
		<set value="3691" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Yahoo">\n\
		<set value="1200" />\n\
		<set value="1124" />\n\
		<set value="1006" />\n\
		<set value="921" />\n\
		<set value="1500" />\n\
		<set value="1007" />\n\
		<set value="921" />\n\
		<set value="971" />\n\
		<set value="1080" />\n\
		<set value="1041" />\n\
		<set value="1113" />\n\
		<set value="1091" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="MSN">\n\
		<set value="400" />\n\
		<set value="524" />\n\
		<set value="606" />\n\
		<set value="421" />\n\
		<set value="500" />\n\
		<set value="707" />\n\
		<set value="621" />\n\
		<set value="471" />\n\
		<set value="680" />\n\
		<set value="441" />\n\
		<set value="713" />\n\
		<set value="491" />\n\
	</dataset>\n\
\n\
	<dataset seriesName="Others">\n\
		<set value="765" />\n\
		<set value="571" />\n\
		<set value="532" />\n\
		<set value="411" />\n\
		<set value="500" />\n\
		<set value="407" />\n\
		<set value="421" />\n\
		<set value="551" />\n\
		<set value="600" />\n\
		<set value="541" />\n\
		<set value="613" />\n\
		<set value="591" />\n\
	</dataset>\n\
</chart>';
