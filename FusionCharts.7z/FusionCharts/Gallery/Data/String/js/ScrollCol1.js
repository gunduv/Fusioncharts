var dataString ='<chart caption="Business Results 2005 v 2006" xAxisName="Month" yAxisName="Revenue" showValues="0" numberPrefix="$" useRoundEdges="1" legendBorderAlpha="100" showBorder="0" bgColor="FFFFFF,FFFFFF" >\n\
\n\
   <categories>\n\
      <category label="Jan" />\n\
      <category label="Feb" />\n\
      <category label="Mar" />\n\
      <category label="Apr" />\n\
      <category label="May" />\n\
      <category label="Jun" />\n\
      <category label="Jul" />\n\
      <category label="Aug" />\n\
      <category label="Sep" />\n\
      <category label="Oct" />\n\
      <category label="Nov" />\n\
      <category label="Dec" />\n\
   </categories>\n\
\n\
   <dataset seriesName="2006">\n\
      <set value="27400" />\n\
      <set value="29800"/>\n\
      <set value="25800" />\n\
      <set value="26800" />\n\
      <set value="29600" />\n\
      <set value="32600" />\n\
      <set value="31800" />\n\
      <set value="36700" />\n\
      <set value="29700" />\n\
      <set value="31900" />\n\
      <set value="34800" />\n\
      <set value="24800" />\n\
   </dataset>\n\
\n\
   <dataset seriesName="2005">\n\
      <set value="10000"/>\n\
      <set value="11500"/>\n\
      <set value="12500"/>\n\
      <set value="15000"/>\n\
      <set value="11000" />\n\
      <set value="9800" />\n\
      <set value="11800" />\n\
      <set value="19700" />\n\
      <set value="21700" />\n\
      <set value="21900" />\n\
      <set value="22900" />\n\
      <set value="20800" />\n\
   </dataset>\n\
\n\
   \n\
</chart>'; 