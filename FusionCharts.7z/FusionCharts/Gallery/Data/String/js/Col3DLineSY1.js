var dataString ='<chart caption="Company Revenue" palette="1" showValues="0" yAxisValuesPadding="10" numberPrefix="$">	\n\
	<categories>\n\
		<category label="Aug 05" />\n\
		<category label="Sep 05" />\n\
		<category label="Oct 05" />\n\
		<category label="Nov 05" />\n\
		<category label="Dec 05" />\n\
        </categories>\n\
\n\
	<dataset seriesName="Product A">\n\
		<set value="36000" />\n\
		<set value="34300" />\n\
		<set value="30000" />\n\
		<set value="27800" />\n\
		<set value="25000" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="Product B">\n\
		<set value="31000" />\n\
		<set value="29300" />\n\
		<set value="26000" />\n\
		<set value="21000" />\n\
		<set value="20500" />\n\
	</dataset>\n\
	\n\
	<dataset seriesname="Predicted" renderAs="Line">\n\
		<set value="25000" />\n\
		<set value="23000" />\n\
		<set value="20000" />\n\
		<set value="18000" />\n\
		<set value="14500" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="2004 Avg." renderAs="Line" >\n\
		<set value="17000" />\n\
		<set value="15000" />\n\
		<set value="16000" />\n\
		<set value="11500" />\n\
		<set value="10000" />\n\
	</dataset>\n\
\n\
</chart>';
