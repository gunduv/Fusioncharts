var dataString ='<chart caption="Daily Dataload" subcaption="(from 5/16/2017 to 5/22/2017)" lineThickness="1" showValues="0" formatNumberScale="0" anchorRadius="2"   divLineAlpha="20" divLineColor="CC3300" divLineIsDashed="1" showAlternateHGridColor="1" alternateHGridColor="CC3300" shadowAlpha="40" labelStep="2" numvdivlines="5" chartRightMargin="35" bgColor="FFFFFF,CC3300" bgAngle="270" bgAlpha="10,10" alternateHGridAlpha="5"  legendPosition ="RIGHT ">\n\
<categories >\n\
<category label="5/16/2017" />\n\
<category label="5/17/2017" />\n\
<category label="5/18/2017" />\n\
<category label="5/19/2017" />\n\
<category label="5/20/2017" />\n\
<category label="5/21/2017" />\n\
<category label="5/22/2017" />\n\
\n\
</categories>\n\
<dataset seriesName="Siebel ROw" color="1D8BD1" anchorBorderColor="1D8BD1" anchorBgColor="1D8BD1">\n\
	<set value="480" />\n\
	<set value="420" />\n\
	<set value="390" />\n\
	<set value="450" />\n\
	<set value="420" />\n\
	<set value="430" />\n\
	<set value="500" />\n\
	</dataset>\n\
\n\
<dataset seriesName="Siebel Service" color="F1683C" anchorBorderColor="F1683C" anchorBgColor="F1683C">\n\
	<set value="120" />\n\
	<set value="130" />\n\
	<set value="120" />\n\
	<set value="150" />\n\
	<set value="145" />\n\
	<set value="125" />\n\
	<set value="140" />\n\
</dataset>\n\
\n\
<dataset seriesName="Customer Master" color="2AD62A" anchorBorderColor="2AD62A" anchorBgColor="2AD62A">\n\
	<set value="60" />\n\
	<set value="55" />\n\
	<set value="70" />\n\
	<set value="65" />\n\
	<set value="60" />\n\
	<set value="62" />\n\
	<set value="70" />\n\
</dataset>\n\
\n\
<dataset seriesName="Norad" color="DBDC25" anchorBorderColor="DBDC25" anchorBgColor="DBDC25">\n\
	<set value="20" />\n\
	<set value="30" />\n\
	<set value="25" />\n\
	<set value="25" />\n\
	<set value="35" />\n\
	<set value="40" />\n\
	<set value="30" />\n\
</dataset>\n\
	<styles>                \n\
		<definition>\n\
                         \n\
			<style name="CaptionFont" type="font" size="12"/>\n\
		</definition>\n\
		<application>\n\
			<apply toObject="CAPTION" styles="CaptionFont" />\n\
			<apply toObject="SUBCAPTION" styles="CaptionFont" />\n\
		</application>\n\
	</styles>\n\
\n\
</chart>';
