var dataString ='<chart palette="4" caption="Web Statistics" pYAxisName="Views" sYAxisName="% of visitors" showValues="0" rotateLabels="1" slantLabels="1" plotSpacePercent="40" sNumberSuffix="%" >\n\
	\n\
	<categories>\n\
		<category label="Jan" />\n\
		<category label="Feb" />\n\
		<category label="Mar" />\n\
		<category label="Apr" />\n\
		<category label="May" />\n\
		<category label="Jun" />\n\
		<category label="Jul" />\n\
		<category label="Aug" />\n\
		<category label="Sep" />\n\
		<category label="Oct" />\n\
		<category label="Nov" />\n\
		<category label="Dec" />\n\
	</categories>\n\
\n\
	<dataset seriesName="Page Views" >\n\
		<set value="36000" />\n\
		<set value="34300" />\n\
		<set value="30000" />\n\
		<set value="27800" />\n\
		<set value="26000" />\n\
		<set value="29000" />\n\
		<set value="32000" />\n\
		<set value="37500" />\n\
		<set value="32000" />\n\
		<set value="28500" />\n\
		<set value="31000" />\n\
		<set value="28000" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="Add to Favorites" parentYAxis="S" color="CC3300">\n\
		<set value="25" />\n\
		<set value="23" />\n\
		<set value="20" />\n\
		<set value="18" />\n\
		<set value="14" />\n\
		<set value="17" />\n\
		<set value="21" />\n\
		<set value="25" />\n\
		<set value="21" />\n\
		<set value="20" />\n\
		<set value="22" />\n\
		<set value="20" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="Set as Home page" parentYAxis="S" color="FFCC33">\n\
		<set value="4" />\n\
		<set value="5" />\n\
		<set value="9" />\n\
		<set value="11" />\n\
		<set value="6" />\n\
		<set value="4" />\n\
		<set value="7" />\n\
		<set value="9" />\n\
		<set value="10" />\n\
		<set value="12" />\n\
		<set value="9" />\n\
		<set value="14" />\n\
	</dataset>\n\
\n\
</chart>';
