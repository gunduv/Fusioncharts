var dataString ='<chart  showLabels="0" showValues="0" showLegend="1"  legendPosition="RIGHT" chartrightmargin="40" bgcolor="ECF5FF" bgalpha="70" bordercolor="C6D2DF"\n\
 basefontcolor="2F2F2F" basefontsize="11" showpercentvalues="1" bgratio="0" startingangle="200" animation="1">\n\
 <set value="20" label="Electric Power Generation" color="005C8E"/>\n\
 <set value="32" label="Industrial Processes" color="00759B"/>\n\
 <set value="12" label="Residential and Commercial Activities" color="0296D2"/>\n\
 <set value="20" label="Agriculture" color="40C7F9"/>\n\
 <set value="2" label="Waste Disposal" color="00496C"/>\n\
 </chart>';
