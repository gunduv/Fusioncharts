var dataString ='<chart decimals="0" showvalues="0" caption="Browser Statistics" xaxisname="No of Visitor" yaxisname="Global Share" animation="1" stack100percent="0" canvasbgangle="0" canvasborderthickness="2" chartleftmargin="5" chartrightmargin="15" charttopmargin="10" chartbottommargin="20" captionpadding="10" xaxisnamepadding="5" yaxisnamepadding="5" yaxisvaluespadding="2" labelpadding="3" basefontsize="13" outcnvbasefontsize="12" zeroplanealpha="80" zeroplanethickness="2" bgcolor="F5F5F5" bgalpha="100" showxaxispercentvalues="1" plotgradientcolor="" basefont="Calibri" canvasbgcolor="FFFFFF" showalternatehgridcolor="0" alternatehgridcolor="FEEFED" divlinealpha="0" usePercentDistribution="0">\n\
	<categories>\n\
		<category label="IE" />\n\
		<category label="Mozilla" />\n\
		<category label="Chrome" />\n\
		<category label="Safari" />\n\
	</categories>\n\
	<dataset seriesName="USA" color="C0E9DE" >\n\
		<set value="61600000"/>\n\
		<set value="39800000"/>\n\
		<set value="16000000"/>\n\
		<set value="8000000"/>\n\
	</dataset>\n\
	<dataset seriesName="Europe"  color="8ABBB1">\n\
		<set value="63000000"/>\n\
		<set value="43800000"/>\n\
		<set value="17000000"/>\n\
		<set value="8380000"/>\n\
	</dataset>\n\
	<dataset seriesName="Rest of the world" color="40847D" >\n\
		<set value="64000000"/>\n\
		<set value="48593000"/>\n\
		<set value="18000000"/>\n\
		<set value="8576900"/>\n\
	</dataset>\n\
	\n\
	</chart>';
