var dataString ='<chart caption="Total crimes for 2005-06 " showValues="0" canvasBgColor="D9E5F1" canvasBaseColor="D9E5F1" >\n\
	\n\
	<categories>\n\
		<category label="Jan" />\n\
		<category label="Feb" />\n\
		<category label="Mar" />\n\
		<category label="Apr" />\n\
		<category label="May" />\n\
		<category label="Jun" />\n\
		<category label="Jul" />\n\
		<category label="Aug" />\n\
		<category label="Sep" />\n\
		<category label="Oct" />\n\
		<category label="Nov" />\n\
		<category label="Dec" />\n\
	</categories>\n\
\n\
	<dataset seriesName="Crimes Reported" >\n\
		<set value="720" />\n\
		<set value="680" />\n\
		<set value="660" />\n\
		<set value="700" />\n\
		<set value="650" />\n\
		<set value="690" />\n\
		<set value="710" />\n\
		<set value="730" />\n\
		<set value="800" />\n\
		<set value="760" />\n\
		<set value="710" />\n\
		<set value="810" />\n\
	</dataset>\n\
\n\
	<dataset seriesname="Crimes Detected" renderAs="Line" color="BBDA00" anchorSides="4" anchorRadius="5" anchorBgColor="BBDA00" anchorBorderColor="FFFFFF" anchorBorderThickness="2">\n\
		<set value="380" />\n\
		<set value="330" />\n\
		<set value="350" />\n\
		<set value="380" />\n\
		<set value="350" />\n\
		<set value="330" />\n\
		<set value="400" />\n\
		<set value="370" />\n\
		<set value="400" />\n\
		<set value="390" />\n\
		<set value="300" />\n\
		<set value="490" />\n\
	</dataset>\n\
\n\
</chart>';
