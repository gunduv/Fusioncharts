var dataString ='<chart palette="2" caption="Country Comparison" showLabels="1" showvalues="0" decimals="0" numberPrefix="$">\n\
<categories><category label="Austria" /><category label="Brazil" /><category label="France" /><category label="Germany" /><category label="USA" /></categories>\n\
<dataset seriesName="1996" color="AFD8F8" showValues="0">\n\
<set value="25601.34" />\n\
<set value="20148.82" />\n\
<set value="17372.76" />\n\
<set value="35407.15" />\n\
<set value="38105.68" />\n\
</dataset>\n\
<dataset seriesName="1997" color="F6BD0F" showValues="0">\n\
<set value="57401.85" />\n\
<set value="41941.19" />\n\
<set value="45263.37" />\n\
<set value="117320.16" />\n\
<set value="114845.27" />\n\
</dataset>\n\
<dataset seriesName="1998" color="8BBA00" showValues="0">\n\
<set value="45000.65" />\n\
<set value="44835.76" />\n\
<set value="18722.18" />\n\
<set value="77557.31" />\n\
<set value="92633.68" />\n\
</dataset>\n\
</chart>';