var dataString ='<chart caption="Engineering Masters Degrees - 2005" baseFontColor="FFFFFF" bgColor="2E4A89, 90B1DE" pieYScale="30"  pieSliceDepth="8" smartLineColor="FFFFFF">\n\
\n\
	<set value="96" label="Computer" color="1160B8"  />\n\
	<set value="87" label="Electrical" color="F2AC0C" />\n\
	<set value="82" label="Mechanical" color="BF0000"/>\n\
	<set value="43" label="Civil" color="00247C"/>\n\
	<set value="55" label="Industrial" color="008900"/>\n\
	<set value="35" label="Biotechnology" color="E95D0F"/>\n\
\n\
	<styles>\n\
\n\
		<definition>\n\
			<style name="CaptionFont" type="FONT" size="12" bold="1" />\n\
			<style name="LabelFont" type="FONT" color="2E4A89" bgColor="FFFFFF" bold="1" />\n\
			<style name="ToolTipFont" type="FONT" bgColor="2E4A89" borderColor="2E4A89" />\n\
		</definition>\n\
\n\
		<application>\n\
        		<apply toObject="CAPTION" styles="CaptionFont" />\n\
        		<apply toObject="DATALABELS" styles="LabelFont" />\n\
        		<apply toObject="TOOLTIP" styles="ToolTIpFont" />\n\
		</application>\n\
\n\
	</styles>\n\
</chart>';